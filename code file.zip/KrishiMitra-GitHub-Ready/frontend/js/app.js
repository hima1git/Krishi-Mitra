'use strict';

const $ = (selector) => document.querySelector(selector);
const form = $('#farm-form');
let csrfToken = '';
let systemInfo = null;
let toastTimer;
const numberFields = ['farm_size', 'nitrogen', 'phosphorus', 'potassium', 'ph', 'temperature', 'rainfall', 'humidity', 'soil_moisture'];
const sample = {district: 'Akola', season: 'Kharif', farm_size: 2.5, nitrogen: 50, phosphorus: 35, potassium: 40, ph: 6.7, temperature: 29, rainfall: 650, humidity: 65, soil_moisture: 40, irrigation: 'no', previous_crop: 'Cotton', scenario: 'below_normal'};
const exampleWeatherFields = new Set();
const scenarioLabels = {normal: 'Normal rainfall', below_normal: 'Below-normal rainfall', severe_stress: 'Severe water stress'};
const climateLabels = {normal: 'Normal / Current Conditions', moderate: 'Moderate El Niño', strong: 'Strong El Niño', extreme: 'Extreme El Niño stress scenario'};
const percent = (number) => `${(number * 100).toFixed(1)}%`;
function cropLabel(crop) {
  const name = crop.display_name_en || crop.crop || crop.name;
  const marathi = crop.crop_marathi || crop.marathi_name;
  return marathi ? `${name} (${marathi})` : name;
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function toast(message) {
  $('#toast').textContent = message;
  $('#toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { $('#toast').hidden = true; }, 5000);
}

function updateClock() {
  const now = new Date();
  const date = new Intl.DateTimeFormat('en-IN', {timeZone:'Asia/Kolkata', day:'2-digit', month:'short', year:'numeric'}).format(now);
  const time = new Intl.DateTimeFormat('en-IN', {timeZone:'Asia/Kolkata', hour:'2-digit', minute:'2-digit', hour12:true}).format(now);
  $('#app-clock').textContent = `${date} · ${time} IST`;
}

function updateInputProvenance() {
  ['temperature','rainfall','humidity'].forEach(key => {
    const label = document.querySelector(`[data-field-source="${key}"]`);
    if (!label) return;
    const hasValue = form.elements.namedItem(key).value.trim() !== '';
    const isExample = hasValue && exampleWeatherFields.has(key);
    label.textContent = !hasValue ? 'UNAVAILABLE · enter local value' : isExample ? 'EXAMPLE INPUT · not a farm reading' : 'FARMER PROVIDED';
    label.classList.toggle('example-source', isExample);
  });
}

async function api(path, options = {}) {
  const response = await fetch(path, {credentials: 'same-origin', ...options,
    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken, ...options.headers}});
  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.error || 'Service unavailable. Check system status.');
    error.fields = data.fields;
    throw error;
  }
  return data;
}

function route() {
  const wanted = location.hash.slice(1) || 'home';
  const page = ['home', 'recommend', 'dashboard', 'profile', 'sources', 'status'].includes(wanted) ? wanted : 'home';
  document.querySelectorAll('.page').forEach(node => { node.hidden = node.id !== `page-${page}`; });
  document.querySelectorAll('nav a').forEach(node => {
    const active = node.dataset.page === page;
    node.classList.toggle('active', active);
    if (active) node.setAttribute('aria-current', 'page'); else node.removeAttribute('aria-current');
  });
  $('#page-title').textContent = {home: 'Overview', recommend: 'Find alternative crops', dashboard: 'My dashboard', profile: 'Farmer profile', sources: 'Data sources', status: 'System status'}[page];
  window.scrollTo(0, 0);
}

function updateHistory(history) {
  $('#history-count').textContent = history.length;
  const list = $('#history-list');
  list.replaceChildren();
  if (!history.length) {
    const empty = element('div', 'empty');
    empty.append(element('h3', '', 'Your next chapter starts with a crop.'), element('p', '', 'Try a recommendation to begin your exploration journal.'));
    const link = element('a', 'button primary', 'Explore alternative crops ↗');
    link.href = '#recommend'; empty.append(link); list.append(empty);
  }
  history.forEach(entry => {
    const row = element('article', 'history-item');
    const content = element('div');
    content.append(element('h3', '', `${entry.inputs.district} · ${entry.inputs.season} · ${scenarioLabels[entry.inputs.scenario]}`));
    content.append(element('p', '', `${entry.created_at} UTC · ${entry.results.map(cropLabel).join(', ') || 'No eligible crops'}`));
    const button = element('button', 'button secondary', 'View results ↗');
    button.type = 'button';
    button.addEventListener('click', () => {
      location.hash = 'recommend'; route();
      showResults({recommendation_id: entry.id, recommendations: entry.results, excluded: null}, entry.inputs);
    });
    row.append(content, button); list.append(row);
  });
}

async function refreshSystem() {
  try {
    systemInfo = await api('/api/system-info');
    csrfToken = systemInfo.csrf_token;
    $('#database-badge').textContent = 'Data storage';
    $('#status-database').textContent = 'Checking…';
    $('#database-detail').textContent = 'Checking application data storage…';
    $('#status-model').textContent = systemInfo.model_status === 'ready' ? 'Model ready' : 'Setup needed';
    $('#weight-explanation').textContent = `${percent(systemInfo.weights.random_forest)} Random Forest + ${percent(systemInfo.weights.collaborative)} collaborative score. Configurable prototype assumptions, not scientifically validated weights.`;
    $('#metrics').replaceChildren();
    if (systemInfo.metrics) {
      [['accuracy', 'Rule-match accuracy · demo'], ['precision_macro', 'Macro precision · demo'], ['recall_macro', 'Macro recall · demo'], ['f1_macro', 'Macro F1 · demo']].forEach(([key, label]) => {
        const metric = element('div', 'metric'); metric.append(element('strong', '', percent(systemInfo.metrics[key])), element('span', '', label)); $('#metrics').append(metric);
      });
    } else $('#metrics').textContent = 'Evaluation report unavailable. Run the evaluation script.';
    updateHistory(systemInfo.history);
    const healthResponse = await fetch('/api/health');
    const health = await healthResponse.json();
    const dataReady = health.database.status === 'ok';
    $('#database-badge').textContent = dataReady ? 'Data storage ready' : 'Data storage unavailable';
    $('#status-database').textContent = dataReady ? 'Available' : 'Unavailable';
    $('#database-detail').textContent = dataReady ? 'Application data storage is available.' : 'Application data storage is unavailable.';
    KrishiDashboard.update(systemInfo, health);
    $('#status-backend').textContent = health.backend_status === 'ok' ? 'Running locally' : 'Needs attention';
    $('#python-version').textContent = `Python ${health.python_version} · Flask`;
    $('#recommend-button').disabled = !healthResponse.ok;
    if (!healthResponse.ok) toast('Setup needs attention. Check system status and the server console.');
  } catch (error) {
    KrishiDashboard.unavailable(error.message);
    $('#database-badge').textContent = 'Connection unavailable';
    $('#status-backend').textContent = 'Unavailable';
    $('#recommend-button').disabled = true;
    toast(error.message);
  }
}

function showResults(data, profile) {
  const assumptions = data.data_assumptions || profile._data_assumptions || [];
  const legacyHistory = !('data_assumptions' in data) && !('_data_assumptions' in profile);
  KrishiDashboard.showAssumptions(assumptions, legacyHistory);
  KrishiDashboard.selectDistrict(profile.district);
  const container = $('#crop-results'); container.replaceChildren();
  $('#results').hidden = false;
  $('#results-summary').textContent = `${profile.district} · ${profile.season} · ${scenarioLabels[profile.scenario]} · ${data.recommendations.length} alternatives`;
  const climate = data.climate_scenario || profile._climate_scenario || {key: profile.climate_scenario || 'normal', label: climateLabels[profile.climate_scenario || 'normal'], stress_level: 'LOW', disclaimer: 'Scenario / Decision Support only; not a rainfall forecast.'};
  $('#climate-scenario-result').textContent = `${climate.label} · ${climate.geographic_scope || 'Vidarbha regional scenario; not calibrated by district'} · ${climate.disclaimer}`;
  const weights = data.weights;
  $('#score-note').textContent = weights ? `Final score = ${percent(weights.random_forest)} RF + ${percent(weights.collaborative)} CF. These are demonstration-model ranking scores, not measured chances of crop success. Water profiles are illustrative.` : 'Saved scores from the original run. Current weights may differ. Scores come from generated demonstration examples and are not measured crop outcomes.';
  if (!data.recommendations.length) container.append(element('p', 'empty', 'No crops passed the current eligibility rules for these inputs.'));
  data.recommendations.forEach((crop, index) => {
    const card = element('article', 'crop-card');
    const top = element('div', 'crop-top'); top.append(element('span', 'rank', `ALTERNATIVE 0${index + 1}`), element('span', 'crop-family', crop.family));
    const image = element('img', 'crop-image'); image.src = crop.image || '/static/images/crop-placeholder.svg';
    const hasPhoto = /\.(?:jpe?g|png|webp)$/i.test(crop.image || '');
    image.alt = hasPhoto ? `${cropLabel(crop)} crop photograph.` : `${cropLabel(crop)} local placeholder illustration; not a crop photograph.`;
    image.addEventListener('error', () => {
      image.onerror = null;
      image.src = '/static/images/crop-placeholder.svg';
      image.alt = `${cropLabel(crop)} local placeholder; photo unavailable.`;
    });
    const final = element('div', 'score-large', percent(crop.final_score)); final.append(element('small', '', 'final score'));
    const tags = element('div', 'crop-tags');
    tags.append(element('span', '', `Illustrative water need: ${crop.water_requirement}`), element('span', '', `Illustrative drought tolerance: ${crop.drought_suitability}`));
    const summary = element('p', 'crop-details', `Water: ${crop.water_requirement} · Drought tolerance: ${crop.drought_suitability} · Duration: ${crop.duration_days ? `${crop.duration_days} days` : 'Unavailable'}`);
    const details = element('details', 'crop-details-disclosure');
    const detailSummary = element('summary', '', 'Crop Details');
    const pair = element('div', 'score-pair');
    [['Random Forest', crop.random_forest_score], ['Collaborative', crop.collaborative_score]].forEach(([label, value]) => { const score = element('div', '', label); score.append(element('strong', '', percent(value))); pair.append(score); });
    const reasons = element('ul'); crop.explanation.forEach(text => reasons.append(element('li', '', window.KrishiLanguage?.translate(text) || text)));
    const scenarioNote = element('p', 'climate-crop-note', `Scenario stress: ${climate.stress_level || 'LOW'}. Suitability change not assessed; verified district crop-response data are unavailable. Existing crop traits are illustrative.`);
    details.append(detailSummary, pair, element('p', 'crop-details', `Scientific name: ${crop.scientific_name || 'Unavailable'} · Weather is not used in the model score.`), reasons, scenarioNote);
    if (crop.image_credit) {
      const credit = element('a', 'image-credit', `${crop.image_credit.creator} · ${crop.image_credit.license} ↗`);
      credit.href = crop.image_credit.source_url; credit.target = '_blank'; credit.rel = 'noopener noreferrer'; details.append(credit);
    } else details.append(element('p', 'image-credit', 'Illustration placeholder; not a crop photograph.'));
    const feedback = element('div', 'feedback');
    const status = element('p', 'feedback-status', 'Your feedback is saved locally.'); status.setAttribute('aria-live', 'polite');
    [['selected', 'Shortlist'], ['accepted', 'Accept'], ['rejected', 'Not for me']].forEach(([action, label]) => {
      const button = element('button', '', label); button.type = 'button';
      button.addEventListener('click', async () => {
        feedback.querySelectorAll('button').forEach(b => { b.disabled = true; });
        try {
          await api('/api/interactions', {method: 'POST', body: JSON.stringify({recommendation_id: data.recommendation_id, crop_id: crop.crop_id, action})});
          feedback.querySelectorAll('button').forEach(b => { b.classList.toggle('chosen', b === button); b.setAttribute('aria-pressed', String(b === button)); });
          status.textContent = `Saved: ${label}. More shared history is needed for personalization.`;
        } catch (error) { status.textContent = error.message; }
        finally { feedback.querySelectorAll('button').forEach(b => { b.disabled = false; }); }
      });
      feedback.append(button);
    });
    card.append(top, image, element('h3', '', cropLabel(crop)), final, tags, summary, details, feedback, status); container.append(card);
  });
  $('#excluded-list').replaceChildren();
  if (data.excluded) data.excluded.forEach(item => $('#excluded-list').append(element('li', '', `${cropLabel(item)}: ${window.KrishiLanguage?.translate(item.reason) || item.reason}`)));
  else $('#excluded-list').append(element('li', '', 'Exclusion details are shown when a new recommendation is generated.'));
  $('#results').scrollIntoView({behavior: 'smooth', block: 'start'});
  $('#results-title').focus({preventScroll: true});
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  $('#form-error').hidden = true;
  form.querySelectorAll('[aria-invalid]').forEach(node => node.removeAttribute('aria-invalid'));
  $('#results').hidden = true;
  const data = Object.fromEntries(new FormData(form));
  data.climate_scenario = data.climate_scenario || 'normal';
  data.field_sources = Object.fromEntries(['temperature','rainfall','humidity'].map(key =>
    [key, exampleWeatherFields.has(key) ? 'example' : 'farmer_provided']));
  // Preserve blanks as null; Number('') would incorrectly turn unknown soil into zero.
  numberFields.forEach(key => { data[key] = data[key].trim() === '' ? null : Number(data[key]); });
  const button = $('#recommend-button'); button.disabled = true; button.textContent = 'Exploring possibilities…';
  try {
    const result = await api('/api/recommend', {method: 'POST', body: JSON.stringify(data)});
    showResults(result, data);
    await refreshSystem();
  } catch (error) {
    const details = Object.entries(error.fields || {}).map(([key, value]) => {
      const field = form.elements.namedItem(key); if (field?.setAttribute) field.setAttribute('aria-invalid', 'true');
      return `${key.replaceAll('_', ' ')}: ${value}`;
    });
    $('#form-error').textContent = [error.message, ...details].join(' ');
    $('#form-error').hidden = false;
    $('#form-error').scrollIntoView({block: 'center'});
  } finally { button.disabled = !csrfToken || systemInfo?.model_status !== 'ready'; button.textContent = 'Find alternative crops ↗'; }
});

$('#sample-button').addEventListener('click', () => {
  Object.entries(sample).forEach(([key, value]) => { form.elements.namedItem(key).value = value; });
  ['temperature','rainfall','humidity'].forEach(key => exampleWeatherFields.add(key));
  updateInputProvenance();
  $('#form-error').hidden = true; $('#results').hidden = true;
  form.querySelectorAll('[aria-invalid]').forEach(node => node.removeAttribute('aria-invalid'));
  toast('Example values loaded. These are not measurements from a real farm.');
});
$('#profile-input-button').addEventListener('click', async () => {
  try {
    const {profile} = await api('/api/profile');
    if (!profile) { toast('No saved profile found. Save your farm details first.'); return; }
    ['district','season'].forEach(key => { if (profile[key]) form.elements.namedItem(key).value = profile[key]; });
    if (profile.total_land != null) {
      const hectares = profile.land_unit === 'acres' ? profile.total_land * 0.40468564224 : profile.total_land;
      form.elements.namedItem('farm_size').value = hectares.toFixed(3);
    }
    if (profile.previous_crops?.length) form.elements.namedItem('previous_crop').value = profile.previous_crops.at(-1);
    ['nitrogen','phosphorus','potassium'].forEach(key => { form.elements.namedItem(key).value = profile[key] ?? ''; });
    ['temperature','rainfall','humidity'].forEach(key => { form.elements.namedItem(key).value = profile[key] ?? ''; });
    ['temperature','rainfall','humidity'].forEach(key => exampleWeatherFields.delete(key));
    updateInputProvenance();
    KrishiDashboard.updateFarmRainfallDefault(profile.district);
    form.elements.namedItem('ph').value = '';
    form.elements.namedItem('soil_moisture').value = '';
    if (profile.irrigated_area > 0) form.elements.namedItem('irrigation').value = 'yes';
    else if (profile.rainfed_area > 0) form.elements.namedItem('irrigation').value = 'no';
    KrishiDashboard.selectDistrict(profile.district);
    toast('Saved profile details copied. Weather inputs remain separate and should not be treated as live data.');
  } catch (error) { toast(error.message); }
});
$('#refresh-status').addEventListener('click', refreshSystem);
$('#refresh-dashboard').addEventListener('click', refreshSystem);
const farmerForm = $('#farmer-profile-form');
const optionalProfileNumbers = ['total_land','irrigated_area','rainfed_area','nitrogen','phosphorus','potassium','latitude','longitude','temperature','rainfall','humidity'];
function fillFarmerProfile(profile) {
  if (!profile) return;
  for (const [key, value] of Object.entries(profile)) {
    const field = farmerForm.elements.namedItem(key);
    if (!field) continue;
    if (field instanceof HTMLSelectElement && field.multiple) {
      [...field.options].forEach(option => { option.selected = (value || []).includes(option.value); });
    } else field.value = value ?? '';
  }
  updateAvatar(profile.name || '');
  if (profile.district) KrishiDashboard.selectDistrict(profile.district);
}
function updateAvatar(name) {
  const initials = name.trim().split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join('').toLocaleUpperCase();
  $('#farmer-avatar').textContent = initials || 'KM';
  $('#farmer-avatar').setAttribute('aria-label', initials ? `Avatar for ${name}` : 'Default farmer initials avatar');
}
async function loadFarmerProfile() {
  try {
    const data = await api('/api/profile');
    fillFarmerProfile(data.profile);
    KrishiDashboard.setFarmerWeather(data.profile);
    $('#profile-status').textContent = data.profile ? `Profile loaded${data.updated_at ? ` · updated ${data.updated_at} UTC` : ''}. Blank soil values remain not provided.` : 'No saved profile yet. Fill in any details you want to store.';
  } catch (error) { $('#profile-status').textContent = `Could not load profile: ${error.message}`; }
}
farmerForm.addEventListener('submit', async event => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(farmerForm));
  optionalProfileNumbers.forEach(key => { data[key] = data[key]?.trim() ? Number(data[key]) : null; });
  ['current_crops','previous_crops','preferred_crops'].forEach(key => {
    data[key] = [...farmerForm.elements.namedItem(key).selectedOptions].map(option => option.value);
  });
  const button = $('#save-profile'); button.disabled = true;
  try {
    const saved = await api('/api/profile', {method: 'PUT', body: JSON.stringify(data)});
    if (data.district) KrishiDashboard.selectDistrict(data.district);
    KrishiDashboard.setFarmerWeather(saved.profile);
    updateAvatar(data.name || '');
    $('#profile-status').textContent = 'Profile saved. Blank soil test values remain marked as not provided.';
    toast('Farmer profile saved.');
  } catch (error) {
    const details = Object.entries(error.fields || {}).map(([key, value]) => `${key.replaceAll('_',' ')}: ${value}`);
    $('#profile-status').textContent = [error.message, ...details].join(' ');
  } finally { button.disabled = false; }
});
farmerForm.elements.namedItem('name').addEventListener('input', event => updateAvatar(event.target.value));
farmerForm.elements.namedItem('district').addEventListener('change', event => KrishiDashboard.selectDistrict(event.target.value));
form.elements.namedItem('district').addEventListener('change', event => {
  KrishiDashboard.selectDistrict(event.target.value);
  KrishiDashboard.updateFarmRainfallDefault(event.target.value);
});
['temperature','rainfall','humidity'].forEach(key => form.elements.namedItem(key).addEventListener('input', () => {
  exampleWeatherFields.delete(key);
  updateInputProvenance();
}));
window.addEventListener('hashchange', route);

async function initialize() {
  route();
  try {
    const data = await api('/api/crops');
    $('#previous-crop').replaceChildren();
    data.previous_crops.forEach(crop => { const option = element('option', '', cropLabel(crop)); option.value = crop.name; $('#previous-crop').append(option); });
    ['current_crops','previous_crops','preferred_crops'].forEach(key => data.previous_crops.filter(crop => crop.name !== 'None').forEach(crop => {
      const option = element('option', '', cropLabel(crop)); option.value = crop.name; farmerForm.elements.namedItem(key).append(option);
    }));
  } catch (error) { toast(error.message); }
  await refreshSystem();
  await loadFarmerProfile();
}
initialize();
updateClock();
setInterval(updateClock, 30000);
updateInputProvenance();
