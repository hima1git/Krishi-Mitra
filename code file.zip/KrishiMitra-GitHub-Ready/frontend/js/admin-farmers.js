'use strict';

const statusNode = document.getElementById('admin-status');
const root = document.getElementById('admin-records');

function text(tag, value) {
  const node = document.createElement(tag);
  node.textContent = value == null || value === '' ? 'Not provided' : String(value);
  return node;
}

function addJson(parent, title, value) {
  const details = document.createElement('details');
  const summary = text('summary', title);
  const pre = text('pre', JSON.stringify(value, null, 2));
  details.append(summary, pre);
  parent.append(details);
}

function renderRecord(record) {
  const section = document.createElement('article');
  section.className = 'admin-record';
  const profile = record.profile || {};
  const summary = document.createElement('h2');
  summary.textContent = `${profile.name || `Anonymous browser profile ${record.user_id}`} · ${profile.district || 'District not provided'}`;
  section.append(summary);
  const metadata = document.createElement('p');
  metadata.textContent = `Profile/user ID ${record.user_id} · first seen ${record.created_at} UTC · profile updated ${record.profile_updated_at || 'never'}`;
  section.append(metadata);
  addJson(section, 'Saved farmer profile fields', profile);
  const history = document.createElement('div');
  const heading = text('h3', `Recommendation history (${record.recommendations.length})`);
  history.append(heading);
  record.recommendations.forEach(run => {
    const runDetails = document.createElement('details');
    const names = (run.results || []).map(crop => crop.display_name_en || crop.crop || crop.name).join(', ') || 'No recommended crops';
    runDetails.append(text('summary', `Recommendation ${run.id} · ${run.district || 'District unknown'} · ${run.season || 'Season unknown'} · ${run.created_at} UTC`));
    const runFields = document.createElement('dl');
    [['Farm profile ID',run.farm_id],['Land area',run.farm_size],['Irrigation',run.irrigation],['Previous crop',run.previous_crop],['Model version',run.model_version],['Recommended crops',names]].forEach(([label,value]) => {
      runFields.append(text('dt',label),text('dd',value));
    });
    runDetails.append(runFields);
    addJson(runDetails, 'Saved recommendation inputs and data provenance', run.inputs);
    addJson(runDetails, 'Saved crop results', run.results);
    addJson(runDetails, 'Saved feedback', run.feedback);
    history.append(runDetails);
  });
  section.append(history);
  return section;
}

async function load() {
  try {
    const response = await fetch('/api/admin/farmers', {cache:'no-store', credentials:'same-origin'});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Local admin viewer unavailable.');
    root.replaceChildren(...data.records.map(renderRecord));
    statusNode.textContent = `${data.records.length} stored browser profile(s) · ${data.database_type.toUpperCase()} database`;
    if (!data.records.length) statusNode.textContent += ' · No farmer records are stored yet.';
  } catch (error) {
    statusNode.textContent = `Could not load records: ${error.message}`;
  }
}

load();
