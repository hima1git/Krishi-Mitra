'use strict';

// The dashboard reads existing API responses; all ML calculations stay in Python.
window.KrishiDashboard = (() => {
  const byId = id => document.getElementById(id);
  const percentage = value => Number.isFinite(value) ? `${(value * 100).toFixed(1)}%` : 'Unavailable';
  let reference = null;
  let selectedDistrict = null;
  let farmerWeather = null;

  const istTime = value => value ? new Date(value).toLocaleString('en-IN', {timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short'}) + ' IST' : 'Unavailable';

  function renderWeather(result) {
    const state = byId('weather-state');
    const values = byId('weather-values');
    const source = byId('weather-source');
    const detail = byId('weather-updated');
    values.replaceChildren();
    const local = farmerWeather && farmerWeather.district === selectedDistrict
      ? Object.fromEntries(['temperature', 'rainfall', 'humidity'].filter(key => farmerWeather[key] != null).map(key => [key, farmerWeather[key]]))
      : {};
    if (Object.keys(local).length) {
      state.textContent = `${selectedDistrict} · FARMER PROVIDED`;
      source.textContent = 'FARMER PROVIDED';
      const labels = {temperature: ['Temperature', '°C'], rainfall: ['Seasonal rainfall', 'mm'], humidity: ['Relative humidity', '%']};
      Object.entries(local).forEach(([key, value]) => {
        const item = node('div', 'regional-reading');
        item.append(node('span', '', labels[key][0]), node('strong', '', `${value} ${labels[key][1]}`), node('small', '', 'Farmer-provided local reading'));
        values.append(item);
      });
      values.hidden = false;
    } else if (result?.status === 'available') {
      const obs = result.observations || {};
      const labels = [['temperature_c','Temperature','°C'],['humidity_percent','Relative humidity','%'],['wind_speed_kmh','Wind speed','km/h'],['wind_direction_degrees','Wind direction','°'],['rainfall_mm_daily','District daily rainfall','mm']];
      labels.forEach(([key,label,unit]) => {
        if (Number.isFinite(obs[key])) {
          const item = node('div','regional-reading');
          item.append(node('span','',label),node('strong','',`${obs[key]} ${unit}`),node('small','','IMD OBSERVED · '+selectedDistrict));
          values.append(item);
        }
      });
      if (obs.weather_code != null) {
        const item = node('div','regional-reading');
        item.append(node('span','','IMD weather code'),node('strong','',String(obs.weather_code)),node('small','','Official code; no condition description inferred'));
        values.append(item);
      }
      if (result.forecast?.days?.length) {
        const item = node('div','regional-reading');
        item.append(node('span','','District rainfall forecast'),node('strong','',result.forecast.days.map(day => day.distribution || 'Unavailable').join(' · ')),node('small','',`IMD FORECAST · issued ${result.forecast.issued || 'date unavailable'}`));
        values.append(item);
      }
      if (result.warnings) {
        const warningText = Object.entries(result.warnings)
          .filter(([key, value]) => key.toLowerCase().startsWith('day') && value)
          .map(([key, value]) => `${key.replace('_',' ')}: ${value}`).join(' · ');
        if (warningText) {
          const item = node('div','regional-reading');
          item.append(node('span','','District weather warning'),node('strong','',warningText),node('small','',`IMD WARNING · issued ${result.warnings.Date || 'date unavailable'} UTC ${result.warnings.UTC || ''}`));
          values.append(item);
        }
      }
      state.textContent = `${selectedDistrict} · IMD district records`;
      source.textContent = 'IMD OBSERVED / FORECAST';
      values.hidden = !values.childElementCount;
      detail.textContent = `Retrieved ${istTime(result.retrieved_at)} · observation ${result.observation_time || 'time unavailable'} · weather is not a Random Forest input.`;
    } else {
      state.textContent = 'IMD data currently unavailable';
      source.textContent = 'HISTORICAL';
      const fallback = result?.district_default;
      if (fallback) {
        [['annual_rainfall_mm','Historical annual normal','mm/year'],['monsoon_rainfall_mm','Historical monsoon normal','mm / June–September']].forEach(([key,label,unit]) => {
          const item = node('div','regional-reading');
          item.append(node('span','',label),node('strong','',`${Number(fallback[key]).toLocaleString('en-IN',{maximumFractionDigits:1})} ${unit}`),node('small','',`HISTORICAL · ${fallback.district} · reference only`));
          values.append(item);
        });
        values.hidden = false;
        detail.textContent = `${result.message} Historical values have no stated averaging period; they are not current rainfall and are not used for recommendations. Retrieved ${istTime(fallback.retrieved_at)}. Source: ICAR-CRIDA.`;
      } else {
        values.hidden = true;
        detail.textContent = `${result?.message || 'No weather source is currently available.'} No current weather numbers are inferred.`;
      }
    }
    if (local && Object.keys(local).length && farmerWeather?.weather_updated_at) {
      detail.textContent = `Farmer-provided readings saved ${istTime(farmerWeather.weather_updated_at)}. IMD values remain separate.`;
    }
  }

  async function loadWeather(district) {
    if (!district) {
      byId('weather-state').textContent = 'Choose a Vidarbha district to view district-specific data.';
      byId('weather-source').textContent = 'NO DISTRICT SELECTED';
      byId('weather-values').hidden = true;
      byId('weather-updated').textContent = 'No district data is selected.';
      return;
    }
    byId('weather-state').textContent = `Checking official IMD data for ${district}…`;
    byId('weather-values').hidden = true;
    try {
      const response = await fetch(`/api/weather/${encodeURIComponent(district)}`);
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Weather service unavailable.');
      if (selectedDistrict !== district) return;
      renderWeather(result);
      if (result.district_default?.source_url) byId('dashboard-source').href = result.district_default.source_url;
    } catch (_) {
      renderWeather({status:'unavailable',message:'Could not contact the local weather adapter.',district_default: reference?.districts[district] ? {
        district, annual_rainfall_mm: reference.districts[district].annual_rainfall_mm,
        monsoon_rainfall_mm: reference.districts[district].monsoon_rainfall_mm,
        retrieved_at:null
      } : null});
    }
  }

  async function loadEnso() {
    const state = byId('enso-state');
    const overviewState = byId('overview-enso-state');
    try {
      const response = await fetch('/api/enso');
      const result = await response.json();
      if (!response.ok) throw new Error('Official outlook is unavailable.');
      const observed = result.observed_enso;
      state.textContent = result.status === 'available'
        ? `${result.state} · ${result.alert_status}${result.trend ? ` · ${result.trend}` : ''}`
        : 'ENSO status unavailable';
      if (overviewState) overviewState.textContent = result.status === 'available'
        ? `${result.state} · ${result.alert_status}${result.trend ? ` · ${result.trend}` : ''}`
        : 'Status unavailable';
      byId('enso-strength').textContent = observed?.status === 'available'
        ? `${observed.strength} · RONI ${Number(observed.value_c) > 0 ? '+' : ''}${Number(observed.value_c).toFixed(2)}°C (${observed.period})`
        : 'Unavailable';
      if (byId('overview-enso-strength')) byId('overview-enso-strength').textContent = observed?.status === 'available'
        ? `${observed.classification} · ${observed.strength}` : 'Strength unavailable';
      const forecast = result.forecast_strength
        ? `NOAA outlook: ${result.forecast_strength}${result.forecast_probability ? ` (${result.forecast_probability} chance)` : ''}. ` : '';
      byId('enso-updated').textContent = result.status === 'available'
        ? `${forecast}NOAA CPC discussion issued ${result.issued}; retrieved ${istTime(result.retrieved_at)}. Global ENSO does not determine district rainfall. Scenario selector is separate.`
        : `${result.message} Scenario selector remains a separate simulation.`;
      if (byId('overview-enso-updated')) byId('overview-enso-updated').textContent = result.status === 'available'
        ? `NOAA CPC · issued ${result.issued}${observed?.period ? ` · RONI ${observed.period}` : ''}`
        : 'NOAA data unavailable';
      if (observed?.message) byId('enso-updated').textContent += ` ${observed.message}`;
      if (observed?.source) byId('enso-obs-source').href = observed.source;
      if (result.source) byId('enso-source').href = result.source;
      if (byId('overview-enso-source') && result.source) byId('overview-enso-source').href = result.source;
    } catch (_) {
      state.textContent = 'ENSO status unavailable';
      if (overviewState) overviewState.textContent = 'Status unavailable';
      byId('enso-strength').textContent = 'Unavailable';
      byId('enso-updated').textContent = 'The NOAA source could not be retrieved. No current status is inferred; the scenario selector remains separate.';
      if (byId('overview-enso-strength')) byId('overview-enso-strength').textContent = 'Strength unavailable';
      if (byId('overview-enso-updated')) byId('overview-enso-updated').textContent = 'NOAA data unavailable';
    }
  }

  function node(tag, className, text) {
    const item = document.createElement(tag);
    item.className = className || '';
    if (text !== undefined) item.textContent = text;
    return item;
  }

  function renderRegion() {
    const values = reference?.districts[selectedDistrict];
    const container = byId('dashboard-regional-readings');
    container.replaceChildren();
    if (!values) {
      container.textContent = 'No reviewed district reference is available.';
      byId('dashboard-source').removeAttribute('href');
      return;
    }
    [['annual_rainfall_mm', 'Historical annual normal', 'mm / year'], ['monsoon_rainfall_mm', 'Historical SW monsoon normal', 'mm / June–September']].forEach(([key, label, unit]) => {
      const reading = node('div', 'regional-reading');
      const value = Number.isFinite(values[key]) ? values[key].toLocaleString('en-IN', {minimumFractionDigits: 1, maximumFractionDigits: 1}) : 'Unavailable';
      reading.append(node('span', '', label), node('strong', '', value), node('small', '', unit)); container.append(reading);
    });
    byId('dashboard-reference-note').textContent = reference.notice;
    byId('dashboard-source').textContent = `${selectedDistrict} · ICAR-CRIDA plan, ${values.source_section}, p. ${values.page} ↗`;
    byId('dashboard-source').href = `${values.source_url}#page=${values.page}`;
    byId('dashboard-source-quality').textContent = reference.quality_note;
    byId('dashboard-soil-availability').textContent = reference.soil_default_notice;
  }

  function selectDistrict(district) {
    selectedDistrict = district;
    if (district) loadWeather(district);
    if (reference?.districts[district]) {
      byId('dashboard-district').value = district;
      renderRegion();
    }
  }

  function updateFarmRainfallDefault(district) {
    const values = reference?.districts[district];
    const target = byId('rainfall-district-default');
    if (!target) return;
    target.textContent = values
      ? `HISTORICAL DISTRICT REFERENCE · ${district}: annual ${values.annual_rainfall_mm.toLocaleString('en-IN')} mm; monsoon ${values.monsoon_rainfall_mm.toLocaleString('en-IN')} mm. ICAR-CRIDA; period unspecified. Not current weather, not a farm reading, and not used as the model input.`
      : 'Choose a district to view its historical rainfall reference.';
  }

  function setFarmerWeather(profile) {
    farmerWeather = profile || null;
    if (selectedDistrict) loadWeather(selectedDistrict);
  }

  function update(info, health) {
    byId('dashboard-error').hidden = true;
    byId('dashboard-crops').textContent = Number.isInteger(info.crop_count) ? info.crop_count : 'Unavailable';
    byId('dashboard-model').textContent = info.model_status === 'ready' ? 'Ready' : 'Not ready';
    byId('dashboard-database').textContent = health.database.status === 'ok' ? 'Available' : 'Unavailable';
    byId('dashboard-database-status').textContent = health.database.status === 'ok' ? 'Connected' : 'Unavailable';
    byId('dashboard-backend').textContent = health.backend_status === 'ok' ? 'Online' : 'Degraded';
    byId('dashboard-updated').textContent = `Checked ${new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}`;
    byId('dashboard-data-badge').textContent = info.model_status === 'ready' ? 'RANDOM FOREST' : 'MODEL UNAVAILABLE';
    const metrics = byId('dashboard-metrics'); metrics.replaceChildren();
    [['accuracy', 'Rule-match accuracy · demo'], ['precision_macro', 'Precision · macro · demo'], ['recall_macro', 'Recall · macro · demo'], ['f1_macro', 'F1 · macro · demo']].forEach(([key, label]) => {
      const metric = node('div', 'dashboard-metric');
      metric.append(node('span', '', label), node('strong', '', percentage(info.metrics?.[key]))); metrics.append(metric);
    });
    byId('dashboard-evaluation-note').textContent = info.metrics
      ? `Evaluation uses ${info.metrics.test_rows.toLocaleString()} independently generated demonstration rows. Rule-match accuracy measures agreement with programmed crop-profile rules; it is not measured on farm outcomes.`
      : 'No matching evaluation report is available for the loaded model. No scores are inferred.';
    const chart = byId('dashboard-features'); const others = byId('dashboard-other-features');
    chart.replaceChildren(); others.replaceChildren();
    const features = info.feature_importances || [];
    features.forEach((entry, index) => {
      const row = node('div', 'feature-row');
      const meter = node('meter'); meter.min = 0; meter.max = 1; meter.value = entry.importance;
      meter.setAttribute('aria-label', `${entry.label}: ${percentage(entry.importance)} of total model importance`);
      row.append(node('span', '', entry.label), meter, node('strong', '', percentage(entry.importance)));
      (index < 8 ? chart : others).append(row);
    });
    if (!features.length) chart.textContent = 'Feature importances unavailable until a model is loaded.';
    others.parentElement.hidden = features.length <= 8;
    reference = info.regional_reference;
    const select = byId('dashboard-district'); select.replaceChildren();
    const prompt = node('option', '', 'Choose district'); prompt.value = ''; select.append(prompt);
    Object.keys(reference.districts).forEach(district => {
      const option = node('option', '', district); option.value = district; select.append(option);
    });
    selectDistrict(selectedDistrict || info.history[0]?.inputs.district || document.querySelector('[name=district]').value || '');
    updateFarmRainfallDefault(document.querySelector('#farm-form [name=district]').value);
    if (info.history_available === false) byId('history-list').textContent = 'Recommendation history is unavailable while the database is offline.';
    loadEnso();
  }

  function unavailable(message) {
    byId('dashboard-error').hidden = false;
    byId('dashboard-error').textContent = `Cannot refresh system data: ${message} Any previously loaded charts are from the last successful check.`;
    ['dashboard-crops','dashboard-model','dashboard-database','dashboard-backend'].forEach(id => { byId(id).textContent = 'Unavailable'; });
    byId('dashboard-database-status').textContent = 'Not verified';
    byId('dashboard-updated').textContent = 'Refresh failed';
  }

  function showAssumptions(assumptions, legacyHistory = false) {
    const panel = byId('data-assumptions'); const list = byId('assumptions-list'); list.replaceChildren();
    panel.hidden = !legacyHistory && !assumptions.length;
    if (legacyHistory) list.append(node('li', '', 'This older saved run has no input-provenance record. Its values cannot be classified retrospectively.'));
    assumptions.forEach(entry => {
      const item = node('li');
      item.append(node('strong', '', `${entry.label}: ${Number(entry.value).toLocaleString('en-IN', {maximumFractionDigits: 2})} ${entry.unit}. `));
      item.append(document.createTextNode(entry.explanation));
      if (entry.source_url) { const link = node('a', '', ' Source'); link.href = entry.source_url; link.target = '_blank'; link.rel = 'noopener noreferrer'; item.append(link); }
      list.append(item);
    });
  }

  byId('dashboard-district').addEventListener('change', event => selectDistrict(event.target.value));
  return {update, unavailable, selectDistrict, showAssumptions, setFarmerWeather, updateFarmRainfallDefault};
})();
