'use strict';

// Source text is the English UI wording; scientific crop names are never translated here.
const translations = {
  mr: {
    'Language': 'भाषा', 'Overview': 'आढावा', 'Find alternative crops': 'पर्यायी पिके शोधा',
    'My dashboard': 'माझा डॅशबोर्ड', 'Farmer profile': 'शेतकरी प्रोफाइल', 'System status': 'प्रणालीची स्थिती',
    'Find your next possibility': 'पुढचा पर्याय शोधा', 'The farm basics': 'शेताची प्राथमिक माहिती',
    'Know your soil': 'तुमची माती जाणून घ्या', 'Weather & water': 'हवामान आणि पाणी',
    'Farmer name': 'शेतकऱ्याचे नाव', 'Village': 'गाव', 'Taluka': 'तालुका', 'District': 'जिल्हा',
    'Total land': 'एकूण जमीन', 'Unit': 'एकक', 'Acres': 'एकर', 'Hectares': 'हेक्टर',
    'Irrigated area': 'सिंचित क्षेत्र', 'Rainfed area': 'पावसावर अवलंबून क्षेत्र',
    'Water source': 'पाण्याचा स्रोत', 'Soil type': 'मातीचा प्रकार', 'Season': 'हंगाम',
    'Latitude': 'अक्षांश', 'Longitude': 'रेखांश', 'Soil and crops': 'माती आणि पिके',
    'Current crops': 'सध्याची पिके', 'Previous crops': 'मागील पिके', 'Preferred crops': 'प्राधान्याची पिके',
    'Save profile': 'प्रोफाइल जतन करा', 'Not provided': 'दिलेली नाहीत',
    'Save only what you choose to share. Soil test fields can stay blank.': 'तुम्ही शेअर करू इच्छिता तीच माहिती जतन करा. माती परीक्षणाची माहिती रिकामी ठेवू शकता.',
    'Blank soil test values remain marked as not provided.': 'रिकामी माती परीक्षण मूल्ये “दिलेली नाहीत” अशीच राहतील.',
    'Random Forest performance': 'Random Forest कामगिरी', 'Important input factors': 'महत्त्वाचे इनपुट घटक',
    'Vidarbha is not one set of conditions': 'विदर्भातील परिस्थिती सर्वत्र सारखी नाही',
    'Recent recommendations': 'अलीकडील शिफारसी', 'Refresh dashboard ↻': 'डॅशबोर्ड रीफ्रेश करा ↻',
    'Crops': 'पिके', 'ML model': 'ML मॉडेल', 'Database': 'डेटाबेस', 'Backend': 'बॅकएंड',
    'State': 'राज्य', 'Data storage': 'माहिती साठवण', 'Data storage ready': 'माहिती साठवण उपलब्ध',
    'Data storage unavailable': 'माहिती साठवण अनुपलब्ध', 'Available': 'उपलब्ध', 'Unavailable': 'अनुपलब्ध',
    'Current crop catalog': 'सध्याची पीक सूची', 'MODEL OUTPUT': 'मॉडेलचा निकाल', 'Load example inputs': 'नमुना इनपुट भरा',
    'Example values loaded. These are not measurements from a real farm.': 'नमुना मूल्ये भरली. ही प्रत्यक्ष शेतातील मोजमापे नाहीत.',
    'Your feedback is saved locally.': 'तुमचा अभिप्राय स्थानिक पातळीवर जतन केला आहे.',
    'No crops passed the current eligibility rules for these inputs.': 'या इनपुटसाठी सध्याचे पात्रता नियम कोणत्याही पिकाला लागू झाले नाहीत.',
    'Rule-match accuracy · demo': 'नियम-जुळणी गुण · प्रात्यक्षिक',
    'Precision · macro · demo': 'प्रिसिजन · मॅक्रो · प्रात्यक्षिक',
    'Recall · macro · demo': 'रिकॉल · मॅक्रो · प्रात्यक्षिक',
    'F1 · macro · demo': 'F1 · मॅक्रो · प्रात्यक्षिक',
    'Macro precision · demo': 'मॅक्रो प्रिसिजन · प्रात्यक्षिक',
    'Macro recall · demo': 'मॅक्रो रिकॉल · प्रात्यक्षिक',
    'Macro F1 · demo': 'मॅक्रो F1 · प्रात्यक्षिक',
    'Random Forest classifier': 'Random Forest वर्गीकरण मॉडेल', 'Reference district': 'संदर्भ जिल्हा',
    'Live IMD data currently unavailable': 'IMD ची थेट माहिती सध्या उपलब्ध नाही',
    'Current weather and forecast': 'सध्याचे हवामान आणि अंदाज',
    'OBSERVED · FORECAST': 'निरीक्षण · अंदाज',
    'Loading IMD weather…': 'IMD हवामान माहिती लोड होत आहे…',
    'Checking official IMD access…': 'IMD चा अधिकृत प्रवेश तपासत आहे…',
    'IMD responded, but its district data could not be verified. Measurements are withheld.': 'IMD कडून प्रतिसाद मिळाला, पण जिल्ह्याची माहिती पडताळता आली नाही. मोजमाप दाखवलेले नाही.',
    'Source: IMD': 'स्रोत: IMD',
    'About your farm': 'तुमच्या शेताबद्दल',
    'Use saved profile details': 'जतन केलेली प्रोफाइल माहिती वापरा',
    'Explore a rainfall scenario': 'पावसाची परिस्थिती तपासा',
    'Normal rainfall': 'सामान्य पाऊस',
    'Below-normal rainfall': 'सामान्यापेक्षा कमी पाऊस',
    'Severe water stress': 'तीव्र पाणीटंचाई',
    'Irrigation available': 'सिंचन उपलब्ध',
    'rainfed': 'पावसावर अवलंबून',
    'No saved profile yet. Fill in any details you want to store.': 'प्रोफाइल अद्याप जतन केलेली नाही. जतन करू इच्छित माहिती भरा.',
    'No saved profile found. Save your farm details first.': 'जतन केलेली प्रोफाइल सापडली नाही. प्रथम शेताची माहिती जतन करा.',
    'Profile saved.': 'प्रोफाइल जतन झाली.',
    'Data sources': 'माहितीचे स्रोत',
    'Data sources and limitations': 'माहितीचे स्रोत आणि मर्यादा',
    'This older saved run has no input-provenance record. Its values cannot be classified retrospectively.': 'या जुन्या नोंदीत इनपुटचा स्रोत जतन केलेला नाही. तिची मूल्ये मागाहून वर्गीकृत करता येत नाहीत.',
    'A learning tool, rooted in transparency.': 'पारदर्शकतेवर आधारलेले शिकण्याचे साधन.',
    'The model uses generated demonstration examples; its scores are not validated farm outcomes. This is not agricultural advice or an El Niño forecast.': 'मॉडेल तयार केलेली प्रात्यक्षिक उदाहरणे वापरते; त्याचे गुण शेतातील निष्कर्षांवर पडताळलेले नाहीत. हा कृषी सल्ला किंवा एल निनोचा अंदाज नाही.',
    'Discover alternative crops for your farm’s conditions. Compare possibilities, explore water-stress scenarios, and understand every recommendation.': 'तुमच्या शेताच्या परिस्थितीसाठी पर्यायी पिके शोधा. पर्यायांची तुलना करा, पाण्याच्या ताणाच्या परिस्थिती तपासा आणि प्रत्येक शिफारस समजून घ्या.',
    'Explore alternative crops': 'पर्यायी पिके तपासा',
    'A simple path to your next crop': 'पुढच्या पिकासाठी सोपा मार्ग',
    'Three steps. Clear explanations.': 'तीन पायऱ्या. स्पष्ट स्पष्टीकरण.',
    'Tell us about your farm': 'तुमच्या शेताबद्दल सांगा',
    'Add your district, soil, season, and water availability. You can try example input values.': 'जिल्हा, माती, हंगाम आणि पाण्याची उपलब्धता भरा. तुम्ही नमुना इनपुट मूल्ये वापरून पाहू शकता.',
    'Compare your alternatives': 'पर्यायांची तुलना करा',
    'See model scores, water profiles, and explanations. Your feedback can help personalize future results.': 'मॉडेलचे गुण, पाण्याचे प्रोफाइल आणि स्पष्टीकरण पहा. तुमचा अभिप्राय पुढील निकाल वैयक्तिक करण्यात मदत करू शकतो.',
    'Designed to explain, not just recommend.': 'फक्त शिफारस नाही, तर स्पष्टीकरण देण्यासाठी बनवले.',
    'Find alternative crops': 'पर्यायी पिके शोधा',
    'Load example inputs': 'नमुना इनपुट भरा',
    'Where, when, and what you’ve grown before.': 'कुठे, केव्हा आणि यापूर्वी काय पिकवले.',
    'Farm size': 'शेताचे क्षेत्र',
    'Previous crop': 'मागील पीक',
    'Nutrient values use illustrative kg/ha inputs. Soil-test methods must match before real use.': 'पोषक मूल्ये प्रात्यक्षिक kg/ha इनपुट वापरतात. प्रत्यक्ष वापरापूर्वी माती परीक्षणाची पद्धत सुसंगत असावी.',
    'Temperature': 'तापमान', 'Seasonal rainfall': 'हंगामी पर्जन्य', 'Relative humidity': 'सापेक्ष आर्द्रता',
    'Irrigation available': 'सिंचन उपलब्ध',
    'Example inputs are prefilled. Recommendations come from a demonstration model and have not been validated against farm outcomes.': 'नमुना इनपुट आधी भरलेले आहेत. शिफारसी प्रात्यक्षिक मॉडेलकडून आहेत आणि शेतातील निष्कर्षांवर पडताळलेल्या नाहीत.',
    'Find alternative crops ↗': 'पर्यायी पिके शोधा ↗',
    'Possibilities worth exploring': 'तपासण्यासारखे पर्याय',
    'A clear view of the model, its inputs, and the evidence behind the recommendations.': 'मॉडेल, त्याचे इनपुट आणि शिफारसींमागील पुरावे स्पष्टपणे पहा.',
    'Refreshing dashboard ↻': 'डॅशबोर्ड रीफ्रेश होत आहे ↻',
    'Loading the current model’s evaluation report.': 'सध्याच्या मॉडेलचा मूल्यांकन अहवाल लोड होत आहे.',
    'What the model uses': 'मॉडेल काय वापरते',
    'View remaining input factors': 'उर्वरित इनपुट घटक पहा',
    'System flow': 'प्रणालीचा प्रवाह',
    'Farmer data': 'शेतकरी माहिती', 'Submitted conditions and optional soil values': 'दिलेल्या परिस्थिती आणि ऐच्छिक माती मूल्ये',
    'Preprocessing': 'पूर्वप्रक्रिया', 'Validation, missing-input handling, encoding': 'पडताळणी, रिकाम्या इनपुटची हाताळणी, एन्कोडिंग',
    'Crop suitability': 'पीक अनुरूपता', 'Current eligibility filters and weighted ranking': 'सध्याचे पात्रता निकष आणि भारित क्रमवारी',
    'Alternative crop recommendations': 'पर्यायी पीक शिफारसी',
    'Reference district': 'संदर्भ जिल्हा', 'Source limitations and soil default availability': 'स्रोतांच्या मर्यादा आणि मातीच्या डीफॉल्टची उपलब्धता',
    'Recent recommendations': 'अलीकडील शिफारसी', 'Data assumptions': 'माहितीविषयक गृहीतके',
    'Recommendation history': 'शिफारस इतिहास',
    'Low': 'कमी', 'Moderate': 'मध्यम', 'High': 'जास्त',
    'Included in the illustrative {season} crop list.': 'उदाहरणार्थ {season} हंगामाच्या पिकांच्या यादीत समाविष्ट.',
    'Illustrative water need: {water}; illustrative drought tolerance: {stress}.': 'उदाहरणातील पाण्याची गरज: {water}; उदाहरणातील दुष्काळ सहनशीलता: {stress}.',
    'An alternative to your previous crop, {crop}.': 'तुमच्या मागील {crop} पिकाला पर्याय.',
    'RF score is a class probability learned from generated demonstration examples, not a measured chance of crop success.': 'RF गुण तयार केलेल्या प्रात्यक्षिक उदाहरणांवर शिकलेल्या वर्गाचे संभाव्यता-मूल्य आहे; ते पीक यशस्वी होण्याची मोजलेली शक्यता नाही.',
    'Insufficient shared interaction history: neutral CF score of 50%.': 'सामायिक अभिप्रायाचा इतिहास अपुरा आहे: CF चा तटस्थ गुण ५०%.',
    'CF uses {count} similar local users.': 'CF {count} सारख्या स्थानिक वापरकर्त्यांचा डेटा वापरते.',
    'Not in the selected season profile.': 'निवडलेल्या हंगामाच्या प्रोफाइलमध्ये नाही.',
    'Previous crop excluded to suggest alternatives.': 'पर्याय सुचवण्यासाठी मागील पीक वगळले आहे.',
    'High illustrative water need with severe stress and no irrigation.': 'तीव्र पाणी ताण आणि सिंचन नसताना उदाहरणातील पाण्याची गरज जास्त आहे.',
    'English': 'English', 'मराठी': 'मराठी',
    'Climate scenario': 'हवामान परिस्थिती',
    'Normal / Current Conditions': 'सामान्य / सध्याची स्थिती',
    'Moderate El Niño': 'मध्यम एल निनो', 'Strong El Niño': 'तीव्र एल निनो',
    'Extreme El Niño stress scenario': 'अत्यंत एल निनो ताण परिस्थिती',
    'Crop Details': 'पीक तपशील',
    'ENSO status and outlook': 'ENSO स्थिती आणि अंदाज',
    'Official global climate outlook': 'अधिकृत जागतिक हवामान अंदाज',
  }
};

const englishText = new WeakMap();
function localizeText(root = document) {
  const language = window.KrishiLanguage?.current || 'en';
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    if (!englishText.has(node)) englishText.set(node, node.nodeValue);
    const original = englishText.get(node);
    const key = original.trim();
    const translated = translations[language]?.[key];
    if (translated) node.nodeValue = original.replace(key, translated);
    else if (language === 'en') node.nodeValue = original;
  }
}

let current = 'en';
try {
  const stored = localStorage.getItem('krishimitra-language');
  if (stored === 'mr') current = stored; else if (stored === 'hi') localStorage.setItem('krishimitra-language', 'en');
} catch (_) { /* Browser storage may be disabled; English remains available. */ }
window.KrishiLanguage = {
  get current() { return current; },
  translate(text) {
    if (current === 'en') return text;
    const dictionary = translations[current] || {};
    let match = text.match(/^Included in the illustrative (.+) crop list\.$/);
    if (match) return (dictionary['Included in the illustrative {season} crop list.'] || text).replace('{season}', match[1]);
    match = text.match(/^Illustrative water need: (.+); illustrative drought tolerance: (.+)\.$/);
    if (match) {
      const term = value => dictionary[value.charAt(0).toUpperCase() + value.slice(1)] || value;
      return (dictionary['Illustrative water need: {water}; illustrative drought tolerance: {stress}.'] || text)
        .replace('{water}', term(match[1])).replace('{stress}', term(match[2]));
    }
    match = text.match(/^An alternative to your previous crop, (.+)\.$/);
    if (match) return (dictionary['An alternative to your previous crop, {crop}.'] || text).replace('{crop}', match[1]);
    match = text.match(/^CF uses (\d+) similar local users\.$/);
    if (match) return (dictionary['CF uses {count} similar local users.'] || text).replace('{count}', match[1]);
    return dictionary[text] || text;
  },
  set(language) {
    current = ['en', 'mr'].includes(language) ? language : 'en';
    document.documentElement.lang = current;
    try { localStorage.setItem('krishimitra-language', current); } catch (_) { /* Preference remains for this page only. */ }
    localizeText();
  }
};

document.addEventListener('DOMContentLoaded', () => {
  document.documentElement.lang = current;
  const picker = document.getElementById('language-select');
  if (picker) {
    picker.value = current;
    picker.addEventListener('change', () => window.KrishiLanguage.set(picker.value));
  }
  localizeText();
  new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(node => {
    if (node.nodeType === Node.TEXT_NODE) localizeText(node.parentElement || document);
    else if (node.nodeType === Node.ELEMENT_NODE) localizeText(node);
  }))).observe(document.body, {childList: true, subtree: true});
});
