from tests.conftest import token


def test_local_admin_view_reads_existing_profile_history_and_feedback(app, client, profile):
    assert client.get('/admin/farmers').status_code == 404
    assert client.get('/api/admin/farmers').status_code == 404
    app.config['LOCAL_ADMIN_VIEW'] = True
    assert client.get('/admin/farmers').status_code == 200
    headers = token(client)
    saved = client.put('/api/profile', json={'name':'Test Farmer','village':'Test village',
        'taluka':'Test taluka','district':'Akola','total_land':2,'land_unit':'acres',
        'state':'Maharashtra','temperature':28,'rainfall':400,'humidity':55}, headers=headers)
    assert saved.status_code == 200
    recommendation = client.post('/api/recommend', json=profile, headers=headers).json
    crop_id = recommendation['recommendations'][0]['crop_id']
    feedback = client.post('/api/interactions', json={'recommendation_id':recommendation['recommendation_id'],
        'crop_id':crop_id,'action':'selected'}, headers=headers)
    assert feedback.status_code == 200
    data = client.get('/api/admin/farmers')
    assert data.status_code == 200
    record, = data.json['records']
    assert record['profile']['name'] == 'Test Farmer'
    assert record['profile']['rainfall'] == 400
    assert len(record['recommendations']) == 1
    assert record['recommendations'][0]['id'] == recommendation['recommendation_id']
    assert record['recommendations'][0]['inputs']['_input_provenance']['nitrogen']['kind'] == 'user_provided'
    assert record['recommendations'][0]['feedback'][0]['action'] == 'selected'
    assert 'anonymous_key' not in str(data.json)


def test_admin_view_rejects_non_loopback_client(app, client):
    app.config['LOCAL_ADMIN_VIEW'] = True
    assert client.get('/admin/farmers', environ_overrides={'REMOTE_ADDR':'203.0.113.20'}).status_code == 404
    assert client.get('/api/admin/farmers', environ_overrides={'REMOTE_ADDR':'203.0.113.20'}).status_code == 404
