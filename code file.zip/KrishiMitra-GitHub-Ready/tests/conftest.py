import pytest

from backend.app import create_app


@pytest.fixture
def app(tmp_path):
    return create_app({'TESTING': True, 'SECRET_KEY': 'test-only-not-a-runtime-secret',
                       'DB_MODE': 'sqlite', 'SQLITE_PATH': str(tmp_path / 'test.db')})


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def profile():
    return dict(district='Akola', season='Kharif', farm_size=2.5, nitrogen=50,
                phosphorus=35, potassium=40, ph=6.7, temperature=29,
                rainfall=650, humidity=65, soil_moisture=40, irrigation='no',
                previous_crop='Cotton', scenario='below_normal')


def token(client):
    return {'X-CSRF-Token': client.get('/api/system-info').get_json()['csrf_token']}
