from pathlib import Path
import json
import shutil
import subprocess

import pytest


ROOT = Path(__file__).resolve().parents[1]


def test_language_picker_is_english_and_marathi_and_crop_names_are_bilingual():
    html = (ROOT / 'frontend' / 'index.html').read_text(encoding='utf-8')
    js = (ROOT / 'frontend' / 'js' / 'i18n.js').read_text(encoding='utf-8')
    app = (ROOT / 'frontend' / 'js' / 'app.js').read_text(encoding='utf-8')
    assert 'value="en"' in html and 'value="mr"' in html and 'value="hi"' not in html
    assert "localStorage.setItem('krishimitra-language', current)" in js
    assert "'Farmer profile': 'शेतकरी प्रोफाइल'" in js
    assert "'Farmer profile': 'किसान प्रोफ़ाइल'" not in js
    assert "['en', 'mr'].includes(language)" in js
    assert "· हिन्दी:" not in app
    assert 'cropLabel(crop)' in app
    assert 'scientific_name' in app or 'scientific_name' in (ROOT / 'backend' / 'catalog.py').read_text(encoding='utf-8')


def test_weather_values_are_not_prefilled_and_current_time_is_dynamic():
    html = (ROOT / 'frontend' / 'index.html').read_text(encoding='utf-8')
    app = (ROOT / 'frontend' / 'js' / 'app.js').read_text(encoding='utf-8')
    assert 'id="app-clock"' in html
    assert "timeZone:'Asia/Kolkata'" in app
    assert 'name="temperature" type="number" min="-10" max="55" step="any" value=' not in html
    assert 'name="rainfall" type="number" min="0" max="4000" step="any" value=' not in html
    assert 'name="humidity" type="number" min="0" max="100" step="any" value=' not in html
    assert 'FARMER PROVIDED' in app and 'EXAMPLE INPUT' in app
    assert 'id="enso-strength"' in html
    assert 'id="rainfall-district-default"' in html
    assert 'not used as the model input' in (ROOT / 'frontend' / 'js' / 'dashboard.js').read_text(encoding='utf-8')
    assert 'value="hi"' not in html
    assert (ROOT / 'frontend' / 'admin-farmers.html').is_file()


def test_weather_values_are_not_prefilled_and_current_time_is_dynamic():
    html = (ROOT / 'frontend' / 'index.html').read_text(encoding='utf-8')
    app = (ROOT / 'frontend' / 'js' / 'app.js').read_text(encoding='utf-8')
    assert 'id="app-clock"' in html
    assert "timeZone:'Asia/Kolkata'" in app
    assert 'name="temperature" type="number" min="-10" max="55" step="any" value=' not in html
    assert 'name="rainfall" type="number" min="0" max="4000" step="any" value=' not in html
    assert 'name="humidity" type="number" min="0" max="100" step="any" value=' not in html
    assert 'FARMER PROVIDED' in app and 'EXAMPLE INPUT' in app
    assert 'id="enso-strength"' in html
    assert 'value="hi"' not in html
    assert (ROOT / 'frontend' / 'admin-farmers.html').is_file()


@pytest.mark.skipif(shutil.which('node') is None, reason='Node.js is not installed for frontend behavior checks')
def test_language_switch_translates_ui_and_recommendation_explanations():
    script = r"""
const fs = require('fs'); const vm = require('vm');
const context = {
  window: {}, NodeFilter: {SHOW_TEXT: 4},
  document: {documentElement: {}, addEventListener() {}, createTreeWalker() { return {nextNode() { return null; }}; }},
  localStorage: {getItem() { return null; }, setItem() {}}
};
vm.createContext(context);
vm.runInContext(fs.readFileSync('frontend/js/i18n.js', 'utf8'), context);
context.window.KrishiLanguage.set('mr');
const mr = context.window.KrishiLanguage.translate('Find alternative crops');
const reason = context.window.KrishiLanguage.translate('Illustrative water need: low; illustrative drought tolerance: high.');
context.window.KrishiLanguage.set('hi');
const unsupported = context.window.KrishiLanguage.translate('Find alternative crops');
console.log(JSON.stringify({mr, unsupported, reason}));
"""
    result = subprocess.run(['node', '-e', script], cwd=ROOT, capture_output=True,
                            text=True, encoding='utf-8', check=True)
    data = json.loads(result.stdout)
    assert data['mr'] == 'पर्यायी पिके शोधा'
    assert data['unsupported'] == 'Find alternative crops'
    assert 'उदाहरणातील पाण्याची गरज' in data['reason']
