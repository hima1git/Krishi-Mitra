from pathlib import Path

from backend.app import create_app

ROOT = Path(__file__).resolve().parents[1]


def profile_app(tmp_path):
    app = create_app({'TESTING': True, 'SQLITE_PATH': str(tmp_path / 'profile.db'),
                      'MODEL_PATH': str(tmp_path / 'missing.joblib'), 'SECRET_KEY': 'test'})
    client = app.test_client()
    info = client.get('/api/system-info').json
    return client, info['csrf_token']


def test_profile_persists_optional_soil_and_crop_preferences(tmp_path):
    client, csrf = profile_app(tmp_path)
    body = {'name': 'Farmer', 'village': 'Test village', 'taluka': 'Test taluka',
            'district': 'Akola', 'total_land': 4, 'land_unit': 'acres',
            'irrigated_area': 1, 'rainfed_area': 3, 'water_source': 'Well',
            'soil_type': '', 'nitrogen': None, 'phosphorus': None, 'potassium': None,
            'current_crops': ['Soybean'], 'previous_crops': ['Cotton'],
            'preferred_crops': ['Chickpea'], 'season': 'Kharif',
            'latitude': None, 'longitude': None,
            'temperature': 28.5, 'rainfall': 612, 'humidity': 61}
    saved = client.put('/api/profile', json=body, headers={'X-CSRF-Token': csrf})
    assert saved.status_code == 200
    loaded = client.get('/api/profile').json
    assert loaded['profile']['nitrogen'] is None
    assert loaded['profile']['current_crops'] == ['Soybean']
    assert loaded['profile']['total_land'] == 4
    assert loaded['profile']['state'] == 'Maharashtra'
    assert loaded['profile']['temperature'] == 28.5
    assert loaded['profile']['rainfall'] == 612
    assert loaded['profile']['humidity'] == 61
    assert loaded['profile']['weather_updated_at'].endswith('+05:30')


def test_profile_rejects_invalid_area_and_district(tmp_path):
    client, csrf = profile_app(tmp_path)
    response = client.put('/api/profile', json={'district': 'Unknown', 'total_land': 1,
        'irrigated_area': 1, 'rainfed_area': 1}, headers={'X-CSRF-Token': csrf})
    assert response.status_code == 400
    assert 'district' in response.json['fields']
    assert 'irrigated_area' in response.json['fields']


def test_crop_catalog_has_regional_names_and_marks_unknowns(tmp_path):
    client, _ = profile_app(tmp_path)
    crops = client.get('/api/crops').json['crops']
    soybean = next(crop for crop in crops if crop['name'] == 'Soybean')
    assert soybean['marathi_name'] == 'सोयाबीन'
    assert soybean['scientific_name'] == 'Glycine max'
    assert soybean['profile_data_status'] == 'illustrative'
    assert soybean['sowing_window'] is None
    assert len(crops) == 8
    for crop in crops:
        assert crop['image'].startswith('/static/images/crops/')
        asset = ROOT / 'frontend' / crop['image'].removeprefix('/static/').replace('/', '\\')
        assert asset.is_file(), crop['name']
        assert client.get(crop['image']).status_code == 200
