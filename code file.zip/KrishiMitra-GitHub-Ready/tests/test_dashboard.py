"""Dashboard values and missing-input provenance; fixtures are not field data."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

import numpy as np
import pytest

from backend.catalog import CROPS, DISTRICTS
from backend.services import regional_data
from backend.services.regional_data import SOIL_FIELDS, resolve_soil_inputs
from tests.conftest import token


def test_dashboard_reports_loaded_model(client, app):
    info = client.get('/api/system-info').json
    assert info['crop_count'] == len(CROPS)
    assert info['model_data_source'] == 'SYNTHETIC_DEMO'
    from backend.config import ROOT
    page = client.get('/').get_data(as_text=True)
    dashboard_js = (ROOT / 'frontend/js/dashboard.js').read_text(encoding='utf-8')
    assert 'generated demonstration examples' in page.lower()
    assert 'Rule-match accuracy · demo' in dashboard_js
    assert 'not measured on farm outcomes' in dashboard_js
    report = json.loads(Path(app.config['MODEL_PATH']).with_name('metrics.json').read_text())
    for field in ['accuracy', 'precision_macro', 'recall_macro', 'f1_macro']:
        assert info['metrics'][field] == report[field]
    rows = info['feature_importances']
    forest = app.extensions['recommender'].bundle['pipeline'].named_steps['forest']
    assert sum(row['importance'] for row in rows) == pytest.approx(forest.feature_importances_.sum())
    assert len(rows) == 14
    assert [r['importance'] for r in rows] == sorted([r['importance'] for r in rows], reverse=True)
    names = app.extensions['recommender'].bundle['pipeline'].named_steps['preprocess'].get_feature_names_out()
    district_sum = sum(value for name, value in zip(names, forest.feature_importances_) if name.startswith('categorical__district_'))
    assert next(row['importance'] for row in rows if row['feature'] == 'district') == pytest.approx(district_sum)


def test_district_references_are_sourced_and_distinct(client):
    reference = client.get('/api/system-info').json['regional_reference']
    assert set(reference['districts']) == set(DISTRICTS)
    assert reference['districts']['Akola']['annual_rainfall_mm'] == 825.3
    assert reference['districts']['Gondia']['annual_rainfall_mm'] == 1377.9
    for district, row in reference['districts'].items():
        assert row['source_url'].startswith('https://icar-crida.res.in/')
        assert row['source_url'].endswith(district + '.pdf')
        assert row['reference_period'] is None


@pytest.mark.parametrize('representation', ['null', 'blank', 'omitted'])
def test_missing_soil_uses_fitted_medians_and_persists_provenance(client, app, profile, representation):
    for field in SOIL_FIELDS:
        if representation == 'omitted':
            profile.pop(field)
        else:
            profile[field] = None if representation == 'null' else '  '
    headers = token(client)
    response = client.post('/api/recommend', json=profile, headers=headers)
    assert response.status_code == 200
    body = response.json
    assert len(body['recommendations']) == 5
    assert len(body['data_assumptions']) == 5
    preprocessing = app.extensions['recommender'].bundle['pipeline'].named_steps['preprocess']
    columns = next(cols for name, _, cols in preprocessing.transformers_ if name == 'numeric')
    medians = preprocessing.named_transformers_['numeric'].named_steps['impute'].statistics_
    for item in body['data_assumptions']:
        assert item['value'] == medians[list(columns).index(item['field'])]
        assert item['basis'] == 'synthetic'
        assert item['tier'] == 'prototype_training_median'
        assert item['district'] == profile['district']
        assert 'not a field measurement' in item['explanation']
    latest = client.get('/api/system-info').json['history'][0]['inputs']
    assert latest['_data_assumptions'] == body['data_assumptions']
    assert latest['_input_provenance']['rainfall']['kind'] == 'user_provided'
    assert latest['rainfall'] == profile['rainfall']  # historical normals never overwrite inputs


def test_filled_values_zero_and_model_are_preserved(client, app, profile):
    path = Path(app.config['MODEL_PATH'])
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    profile['nitrogen'] = 0
    response = client.post('/api/recommend', json=profile, headers=token(client))
    assert response.status_code == 200
    assert response.json['data_assumptions'] == []
    assert all(item['kind'] == 'user_provided' for item in response.json['input_provenance'].values())
    latest = client.get('/api/system-info').json['history'][0]['inputs']
    assert latest['nitrogen'] == 0
    assert latest['ph'] == profile['ph']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == before


def test_default_hierarchy_and_user_override(app, profile):
    registry = deepcopy(regional_data.REFERENCE)
    # Deliberately artificial fixture to exercise precedence, not production data.
    base = dict(unit='kg/ha', source_url='https://example.test/fixture-only',
                period='test period', method='test method', scope='fixture only', reviewed_for_model_input=True)
    registry['soil_defaults']['districts']['Akola'] = {'nitrogen': dict(base, value=81)}
    registry['soil_defaults']['vidarbha'] = {'nitrogen': dict(base, value=72)}
    bundle = app.extensions['recommender'].bundle
    supplied, _, assumptions = resolve_soil_inputs(profile, bundle, registry)
    assert supplied['nitrogen'] == 50 and assumptions == []
    profile['nitrogen'] = None
    district, _, notes = resolve_soil_inputs(profile, bundle, registry)
    assert district['nitrogen'] == 81
    assert notes[0]['tier'] == 'documented_district_estimate'
    profile['district'] = 'Gondia'
    regional, _, notes = resolve_soil_inputs(profile, bundle, registry)
    assert regional['nitrogen'] == 72
    assert notes[0]['tier'] == 'documented_regional_estimate'
    registry['soil_defaults']['vidarbha']['nitrogen']['unit'] = 'mg/kg'
    _, _, notes = resolve_soil_inputs(profile, bundle, registry)
    assert notes[0]['tier'] == 'prototype_training_median'  # no ungrounded unit conversion


@pytest.mark.parametrize('field,value', [('nitrogen', 'nan'), ('ph', 15), ('potassium', -1), ('soil_moisture', True)])
def test_invalid_supplied_soil_is_not_replaced(client, profile, field, value):
    profile[field] = value
    result = client.post('/api/recommend', json=profile, headers=token(client))
    assert result.status_code == 400
    assert field in result.json['fields']


def test_other_required_inputs_still_required(client, profile):
    profile['temperature'] = None
    result = client.post('/api/recommend', json=profile, headers=token(client))
    assert result.status_code == 400


def test_example_weather_inputs_keep_explicit_non_farmer_provenance(client, profile):
    profile['field_sources'] = {'temperature':'farmer_provided', 'rainfall':'example', 'humidity':'farmer_provided'}
    response = client.post('/api/recommend', json=profile, headers=token(client))
    assert response.status_code == 200
    assert response.json['input_provenance']['rainfall']['kind'] == 'example_input'
    assert response.json['input_provenance']['temperature']['kind'] == 'user_provided'
    latest = client.get('/api/system-info').json['history'][0]['inputs']
    assert latest['_field_sources']['rainfall'] == 'example'
    assert 'not a measurement from a farmer' in latest['_input_provenance']['rainfall']['explanation']


def test_dashboard_assets_and_optional_controls(client):
    html = client.get('/').text
    assert 'Krishi Mitra Dashboard' in html
    assert client.get('/static/css/dashboard.css').status_code == 200
    assert client.get('/static/js/dashboard.js').status_code == 200
    from html.parser import HTMLParser
    class Inputs(HTMLParser):
        fields = {}
        def handle_starttag(self, tag, attrs):
            if tag == 'input':
                attributes = dict(attrs)
                self.fields.setdefault(attributes.get('name'), []).append(attributes)
    parser = Inputs()
    parser.feed(html)
    assert all(all('required' not in attrs for attrs in parser.fields[field]) for field in SOIL_FIELDS)
    assert all(any('required' in attrs for attrs in parser.fields[field])
               for field in ('temperature', 'rainfall', 'humidity'))


def test_five_crop_photographs_are_local_and_have_license_metadata(client):
    crops = client.get('/api/crops').json['crops']
    photos = [crop for crop in crops if crop['image'].lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))]
    assert len(photos) >= 5
    for crop in photos:
        assert crop['image_credit']['source_url'].startswith('https://commons.wikimedia.org/wiki/File:')
        assert crop['image_credit']['creator'] and crop['image_credit']['license']
        response = client.get(crop['image'])
        assert response.status_code == 200
        assert response.mimetype == 'image/jpeg'


def test_missing_model_does_not_invent_importances(app, client):
    app.extensions['recommender'].bundle = None
    app.extensions['recommender'].status = 'missing'
    data = client.get('/api/system-info').json
    assert data['feature_importances'] == []
    assert data['metrics'] is None
    assert data['model_data_source'] is None


def test_offline_database_still_allows_status(app, client, monkeypatch):
    monkeypatch.setattr(app.extensions['store'], 'healthy', lambda: False)
    assert client.get('/api/system-info').json['history_available'] is False
    health = client.get('/api/health')
    assert health.status_code == 503
    assert health.json['database']['status'] == 'unavailable'
