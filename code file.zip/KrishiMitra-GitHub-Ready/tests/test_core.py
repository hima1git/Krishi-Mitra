import json
import sqlite3

import numpy as np
import pandas as pd
import pytest
from sklearn.ensemble import RandomForestClassifier

from backend.database.store import Store
from backend.services.collaborative import collaborative_score
from tests.conftest import token


def test_health_and_secrets(client):
    response = client.get('/api/health')
    assert response.status_code == 200
    assert response.json['database']['type'] == 'sqlite'
    assert response.json['ml_model']['status'] == 'ready'
    info = client.get('/api/system-info').get_json()
    assert 'MYSQL_PASSWORD' not in json.dumps(info)
    assert 'generated demonstration examples' in info['disclaimer']
    assert len(client.get('/api/crops').json['crops']) == 8


def test_real_model_probabilities(app, profile):
    bundle = app.extensions['recommender'].bundle
    pipeline = bundle['pipeline']
    assert isinstance(pipeline.named_steps['forest'], RandomForestClassifier)
    probabilities = pipeline.predict_proba(pd.DataFrame([profile]))[0]
    assert np.isclose(probabilities.sum(), 1)
    assert len(probabilities) == 8


def test_evaluation_reproducible_after_csv_reload(app):
    from backend.config import ROOT
    from ml.evaluate_model import evaluate
    data = pd.read_csv(ROOT / 'ml/data/holdout.csv', keep_default_na=False, float_precision='round_trip')
    report = evaluate(app.extensions['recommender'].bundle, data)
    saved = json.loads((ROOT / 'ml/models/metrics.json').read_text())
    assert report['accuracy'] == saved['accuracy']
    assert report['confusion_matrix'] == saved['confusion_matrix']


def test_synthetic_rule_match_accuracy_uses_independent_holdout(app):
    from backend.config import ROOT
    from ml.preprocess import FEATURES, TARGET
    bundle = app.extensions['recommender'].bundle
    report = json.loads((ROOT / 'ml/models/metrics.json').read_text())
    training = pd.read_csv(ROOT / 'ml/data/synthetic_demo.csv', keep_default_na=False,
                            float_precision='round_trip')
    holdout = pd.read_csv(ROOT / 'ml/data/holdout.csv', keep_default_na=False,
                          float_precision='round_trip')
    assert bundle['label_method'] == 'deterministic_argmax_of_synthetic_crop_profile_score'
    assert bundle['holdout_seed'] != 42
    assert len(training) == bundle['training_rows'] == 4800
    assert len(holdout) == bundle['test_rows'] == 1200
    assert report['accuracy'] > 0.80
    assert 'not agricultural validity' in report['notice']
    assert not training[FEATURES + [TARGET]].merge(
        holdout[FEATURES + [TARGET]], how='inner').shape[0]


def test_frontend_assets(client):
    assert client.get('/').status_code == 200
    assert b'Find your next possibility' in client.get('/').data
    assert client.get('/static/css/style.css').status_code == 200
    assert client.get('/static/js/app.js').status_code == 200
    assert client.get('/.env').status_code == 404


def test_recommendation_persistence_and_feedback(client, app, profile):
    headers = token(client)
    response = client.post('/api/recommend', json=profile, headers=headers)
    assert response.status_code == 200
    data = response.json
    assert len(data['recommendations']) == 5
    for crop in data['recommendations']:
        assert crop['crop_marathi']
        assert crop['crop_hindi']
        assert crop['image'].startswith('/static/images/')
        assert any('generated demonstration examples' in reason.lower() for reason in crop['explanation'])
        assert crop['collaborative_score'] == .5
        assert crop['collaborative_mode'] == 'neutral_fallback'
        assert crop['final_score'] == pytest.approx(.8 * crop['random_forest_score'] + .2 * .5)
    scores = [r['final_score'] for r in data['recommendations']]
    assert scores == sorted(scores, reverse=True)
    body = dict(recommendation_id=data['recommendation_id'], crop_id=data['recommendations'][0]['crop_id'], action='accepted')
    assert client.post('/api/interactions', json=body, headers=headers).status_code == 200
    body['action'] = 'rejected'
    assert client.post('/api/interactions', json=body, headers=headers).status_code == 200
    store = app.extensions['store']
    assert len(store.interactions()) == 1
    assert store.interactions()[0]['action'] == 'rejected'
    assert len(client.get('/api/system-info').json['history']) == 1
    with store.connection() as conn:
        for table in ('farm_profiles', 'soil_data', 'weather_data', 'recommendations'):
            assert store.execute(conn, f'SELECT COUNT(*) AS n FROM {table}', fetch=True)[0]['n'] == 1


@pytest.mark.parametrize('field,value', [('ph', 20), ('humidity', -1), ('farm_size', 0),
                                        ('temperature', 'nan'), ('rainfall', 'inf'),
                                        ('nitrogen', True), ('season', 'Summer'),
                                        ('district', "Akola'; DROP TABLE crops;--"),
                                        ('scenario', 'El Niño prediction')])
def test_invalid_input(client, profile, field, value):
    profile[field] = value
    response = client.post('/api/recommend', json=profile, headers=token(client))
    assert response.status_code == 400
    assert field in response.json['fields']


def test_bad_payload_and_csrf(client):
    assert client.post('/api/recommend', json={}).status_code == 403
    headers = token(client)
    assert client.post('/api/recommend', json=[], headers=headers).status_code == 400
    assert client.post('/api/recommend', data='{', content_type='application/json', headers=headers).status_code == 400
    assert client.post('/api/recommend', data='a=b', headers=headers).status_code == 415
    assert client.get('/api/unknown').status_code == 404


def test_interaction_ownership(app, client, profile):
    response = client.post('/api/recommend', json=profile, headers=token(client)).json
    other = app.test_client()
    result = other.post('/api/interactions', headers=token(other), json={
        'recommendation_id': response['recommendation_id'],
        'crop_id': response['recommendations'][0]['crop_id'], 'action': 'accepted'})
    assert result.status_code == 404


def test_severe_water_filter_and_previous_crop(client, profile):
    profile.update(scenario='severe_stress', irrigation='no', previous_crop='Sorghum')
    response = client.post('/api/recommend', json=profile, headers=token(client)).json
    assert all(c['crop'] not in ['Rice', 'Sorghum', 'Wheat', 'Chickpea'] for c in response['recommendations'])
    assert any(e['crop'] == 'Rice' for e in response['excluded'])


def test_rabi_can_return_fewer_than_three(client, profile):
    profile.update(season='Rabi', scenario='severe_stress', previous_crop='Sorghum')
    result = client.post('/api/recommend', json=profile, headers=token(client)).json
    assert [c['crop'] for c in result['recommendations']] == ['Chickpea']


def test_collaborative_real_neighbor_path():
    rows = [dict(user_id=u, crop_id=c, action='accepted') for u in (1, 2, 3) for c in (1, 2)]
    rows += [dict(user_id=u, crop_id=3, action='accepted') for u in (2, 3)]
    result = collaborative_score(1, 3, rows)
    assert result == {'score': 1, 'mode': 'collaborative', 'neighbors': 2}
    for row in rows:
        if row['crop_id'] == 3:
            row['action'] = 'rejected'
    assert collaborative_score(1, 3, rows)['score'] == 0
    assert collaborative_score(99, 3, rows)['mode'] == 'neutral_fallback'


def test_database_foreign_keys_and_reinitialization(app):
    store = app.extensions['store']
    store.initialize()
    with store.connection() as conn:
        assert store.execute(conn, 'SELECT COUNT(*) AS n FROM crops', fetch=True)[0]['n'] == 8
    with pytest.raises(sqlite3.IntegrityError):
        with store.connection() as conn:
            store.execute(conn, 'INSERT INTO farm_profiles (user_id,district,season,farm_size,irrigation,previous_crop) VALUES (?,?,?,?,?,?)', (999, 'Akola', 'Rabi', 1, 'no', 'None'))


def test_mysql_fallback(app, monkeypatch, tmp_path):
    import mysql.connector
    def unavailable(self):
        raise mysql.connector.Error('simulated unavailable server')
    monkeypatch.setattr(Store, '_mysql', unavailable)
    config = dict(app.config, DB_MODE='auto', MYSQL_USER='test', MYSQL_DATABASE='test', SQLITE_PATH=str(tmp_path / 'fallback.db'))
    assert Store(config).kind == 'sqlite'
    config['DB_MODE'] = 'mysql'
    with pytest.raises(RuntimeError, match='MySQL connection failed'):
        Store(config)


def test_missing_model_degraded(tmp_path):
    from backend.app import create_app
    app = create_app({'TESTING': True, 'SECRET_KEY': 'test-only', 'DB_MODE': 'sqlite',
                      'SQLITE_PATH': str(tmp_path / 'empty.db'), 'MODEL_PATH': str(tmp_path / 'missing.joblib')})
    response = app.test_client().get('/api/health')
    assert response.status_code == 503
    assert 'missing' in response.json['ml_model']['status']
