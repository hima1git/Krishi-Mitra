from urllib.error import HTTPError

from backend.app import create_app
from backend.services.weather import IMDWeatherService


def test_unconfigured_weather_is_explicit_and_does_not_call_network():
    calls = []
    service = IMDWeatherService({}, fetcher=lambda *args: calls.append(args))
    result = service.for_district('Akola')
    assert result['status'] == 'unavailable'
    assert result['observations'] is None
    assert result['model_input'] is False
    assert calls == []


def test_configured_weather_fetches_district_records_and_caches():
    now = [10]
    calls = []

    def fetch(url, header, value, timeout):
        calls.append((url, header, timeout))
        if 'aws_data' in url:
            return [{'DISTRICT': 'AKOLA', 'STATION': 'AKOLA', 'DATE': '2026-09-27',
                     'TIME': '09:00:00', 'CURR_TEMP': '31.5', 'RH': '42',
                     'WIND_SPEED': '4', 'WIND_DIRECTION': '180'}]
        if 'state_district_rainfall_forecast' in url:
            return [{'District':'AKOLA','date_obs':'2026-09-27','day1_distribution':'Isolated'}]
        if 'districtwarning' in url:
            return [{'District':'AKOLA','Date':'2026-09-27','Day_1':'No Warning'}]
        return [{'District':'AKOLA','Date':'2026-09-27','Daily Actual':'12.5'}]

    service = IMDWeatherService({'IMD_API_AUTH_HEADER': 'X-Approved',
                                 'IMD_API_AUTH_VALUE': 'credential',
                                 'IMD_CACHE_SECONDS': 20}, fetcher=fetch,
                                clock=lambda: now[0])
    first = service.for_district('Akola')
    second = service.for_district('Akola')
    assert first['status'] == 'available'
    assert first['model_input'] is False
    assert first['observations']['temperature_c'] == 31.5
    assert first['observations']['rainfall_mm_daily'] == 12.5
    assert first['forecast']['days'][0]['distribution'] == 'Isolated'
    assert first['district'] == 'Akola'
    assert second == first and len(calls) == 4
    assert all(call[1] == 'X-Approved' for call in calls)


def test_live_weather_uses_only_the_selected_district_record():
    def fetch(url, *_):
        if 'aws_data' in url:
            return [{'DISTRICT':'AKOLA','CURR_TEMP':'30'}, {'DISTRICT':'GONDIA','CURR_TEMP':'27'}]
        if 'state_district_rainfall_forecast' in url:
            return [{'District':'AKOLA','day1_distribution':'Isolated'}, {'District':'GONDIA','day1_distribution':'Widespread'}]
        if 'districtwarning' in url:
            return []
        return [{'District':'AKOLA','Daily Actual':'5'}, {'District':'GONDIA','Daily Actual':'18'}]

    service = IMDWeatherService({'IMD_API_AUTH_HEADER':'X-Approved','IMD_API_AUTH_VALUE':'allowed'}, fetcher=fetch)
    akola = service.for_district('Akola')
    gondia = service.for_district('Gondia')
    assert akola['observations']['temperature_c'] == 30
    assert akola['rainfall'] == 5
    assert gondia['observations']['temperature_c'] == 27
    assert gondia['rainfall'] == 18
    assert akola['forecast']['days'][0]['distribution'] == 'Isolated'
    assert gondia['forecast']['days'][0]['distribution'] == 'Widespread'


def test_auth_failure_returns_safe_unavailable_state():
    def fetch(*args):
        raise HTTPError(args[0], 401, 'unauthorized', {}, None)

    service = IMDWeatherService({'IMD_API_AUTH_HEADER': 'Authorization',
                                 'IMD_API_AUTH_VALUE': 'secret'}, fetcher=fetch)
    result = service.for_district('Akola')
    assert result['status'] == 'unavailable'
    assert 'secret' not in str(result)
    assert result['observations'] is None


def test_weather_route_returns_distinct_historical_fallback_without_live_values(tmp_path):
    app = create_app({'TESTING': True, 'SQLITE_PATH': str(tmp_path / 'test.db'),
                      'MODEL_PATH': str(tmp_path / 'missing.joblib'), 'SECRET_KEY': 'test'})
    client = app.test_client()
    for district in ('Akola', 'Amravati', 'Buldhana', 'Washim', 'Yavatmal', 'Wardha',
                     'Nagpur', 'Bhandara', 'Gondia', 'Chandrapur', 'Gadchiroli'):
        response = client.get(f'/api/weather/{district}')
        assert response.status_code == 200
        assert response.json['status'] == 'unavailable'
        assert response.json['rainfall'] is None
        assert response.json['observations'] is None
        fallback = response.json['district_default']
        assert fallback['district'] == district
        assert fallback['data_type'] == 'historical'
        assert fallback['fallback'] is True
        assert fallback['source_url'].startswith('https://icar-crida.res.in/')
    akola = client.get('/api/weather/Akola').json['district_default']
    gondia = client.get('/api/weather/Gondia').json['district_default']
    assert akola['annual_rainfall_mm'] != gondia['annual_rainfall_mm']
    assert client.get('/api/weather/Not-A-District').status_code == 400
