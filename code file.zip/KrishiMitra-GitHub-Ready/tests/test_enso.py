import json

import pytest

from backend.services.enso import ENSOService
from tests.conftest import token


def test_scenario_config_is_centralized_and_non_numeric():
    config = ENSOService.scenarios()
    assert set(config['scenarios']) == {'normal', 'moderate', 'strong', 'extreme'}
    assert 'not calibrated by district' in config['geographic_scope']
    assert 'not a prediction' in config['disclaimer']
    assert 'rainfall calibration' in config['historical_basis']['use']
    assert not any(isinstance(value, (float, int)) for row in config['scenarios'].values() for value in row.values())


def test_noaa_outlook_source_and_issue_date_are_explicit_and_cached():
    calls = []
    html = ('<html><p>CLIMATE PREDICTION CENTER/NCEP/NWS</p><p>10 September 2026</p>'
            '<p>ENSO Alert System Status: El Niño Advisory</p><p>Synopsis: El Niño is strengthening, '
            'with a greater than 90% chance of a very strong event during fall and winter.</p>')
    service = ENSOService(fetcher=lambda url, timeout: calls.append((url, timeout)) or html,
                          clock=lambda: 100, cache_seconds=60)
    first = service.official_outlook()
    second = service.official_outlook()
    assert first['status'] == 'available'
    assert first['state'] == 'El Niño'
    assert first['alert_status'] == 'El Niño Advisory'
    assert first['trend'] == 'strengthening'
    assert first['forecast_strength'] == 'Very Strong'
    assert first['forecast_probability'] == '>90%'
    assert first['issued'] == '10 September 2026'
    assert first['source'].startswith('https://www.cpc.ncep.noaa.gov/')
    assert first == second and len(calls) == 2
    assert 'not a Vidarbha rainfall forecast' in first['message']


def test_noaa_failure_does_not_infer_current_status():
    service = ENSOService(fetcher=lambda *_: (_ for _ in ()).throw(OSError('offline')))
    result = service.official_outlook()
    assert result['status'] == 'unavailable'
    assert result['state'] == 'unavailable'
    assert result['issued'] is None
    assert 'no current status is inferred' in result['message']


def test_roni_episode_requires_five_consecutive_official_periods():
    service = ENSOService(clock=lambda: 1790380800)
    row = '<tr><td>2026</td>' + ''.join('<td>0.8</td>' for _ in range(12)) + '</tr>'
    roni = service._latest_roni(f'<table>{row}</table>', 1790380800)
    assert roni['classification'] == 'El Niño'
    assert roni['strength'] == 'Weak'
    assert roni['period'] == 'JJA 2026'
    assert roni['value_c'] == 0.8
    assert 'do not predict district rainfall in Vidarbha' in roni['message']


def test_recommendation_scenarios_do_not_change_model_scores(client, profile):
    headers = token(client)
    results = {}
    for district in ['Akola', 'Yavatmal', 'Nagpur', 'Gondia']:
        for scenario in ['normal', 'moderate', 'strong', 'extreme']:
            payload = dict(profile, district=district, climate_scenario=scenario)
            response = client.post('/api/recommend', json=payload, headers=headers)
            assert response.status_code == 200, response.get_json()
            body = response.json
            climate = body['climate_scenario']
            assert climate['key'] == scenario
            assert climate['district'] == district
            assert climate['geographic_scope'] == 'Vidarbha regional scenario; not calibrated by district'
            assert climate['disclaimer'].startswith('Scenario / Decision Support')
            assert all(crop['climate_scenario']['suitability_change'] == 'not_assessed'
                       for crop in body['recommendations'])
            assert all('not used' not in crop['climate_scenario']['consideration']
                       for crop in body['recommendations'])
            assert [item['random_forest_score'] for item in body['recommendations']]
            results.setdefault(district, {})[scenario] = {
                item['crop_id']: item['random_forest_score'] for item in body['recommendations']
            }
    for district, scenarios in results.items():
        baseline = scenarios['normal']
        for scenario, scores in scenarios.items():
            assert scores.keys() == baseline.keys(), (district, scenario)
            assert scores == pytest.approx(baseline, abs=1e-12), (district, scenario)


def test_unknown_climate_scenario_is_rejected(client, profile):
    payload = dict(profile, climate_scenario='live_el_nino_forecast')
    response = client.post('/api/recommend', json=payload, headers=token(client))
    assert response.status_code == 400
    assert 'climate_scenario' in response.json['fields']


def test_official_outlook_is_separate_from_weather_and_scenario(client, app):
    app.extensions['enso'].fetcher = lambda *_: ('<p>10 September 2026</p><p>ENSO Alert System Status: El Niño Advisory</p>'
        '<p>Synopsis: El Niño is strengthening. The event has a 90% chance of a very strong event.</p>')
    response = client.get('/api/enso')
    assert response.status_code == 200
    assert 'rainfall' not in response.json
    assert 'scenario' not in response.json
    assert response.json['status'] == 'available'
    assert response.json['state'] == 'El Niño'
    assert response.json['source'].endswith('ensodisc.html')


def test_official_scenario_options_remain_separate():
    scenarios = ENSOService.scenarios()['scenarios']
    assert set(scenarios) == {'normal','moderate','strong','extreme'}
    assert scenarios['extreme']['label'].lower().find('scenario') >= 0
