"""Application factory; normal startup loads the model without training."""
import os
import secrets
from pathlib import Path

from flask import Flask, abort, jsonify, request, send_from_directory
from werkzeug.exceptions import HTTPException

from backend.config import ROOT, settings
from backend.database.store import Store
from backend.routes.api import api
from backend.services.recommendation import Recommender
from backend.services.weather import IMDWeatherService
from backend.services.enso import ENSOService
from backend.utils.validation import ValidationError


def create_app(overrides=None):
    app = Flask(__name__, static_folder=str(ROOT / 'frontend'), static_url_path='/static')
    app.config.update(settings())
    if overrides:
        app.config.update(overrides)
    if not app.config.get('SECRET_KEY'):
        secret_path = ROOT / 'instance' / 'session.key'
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        if not secret_path.exists():
            try:
                with secret_path.open('x', encoding='utf-8') as file:
                    file.write(secrets.token_hex(32))
            except FileExistsError:
                pass
        app.config['SECRET_KEY'] = secret_path.read_text(encoding='utf-8').strip()
    app.extensions['store'] = Store(app.config)
    app.extensions['recommender'] = Recommender(app.config)
    app.extensions['weather'] = IMDWeatherService(app.config)
    app.extensions['enso'] = ENSOService()
    app.register_blueprint(api)

    @app.get('/')
    def index():
        return send_from_directory(ROOT / 'frontend', 'index.html')

    @app.get('/admin/farmers')
    def local_admin_farmers():
        import ipaddress
        remote = request.remote_addr or ''
        try:
            loopback = ipaddress.ip_address(remote).is_loopback
        except ValueError:
            loopback = False
        if not app.config.get('LOCAL_ADMIN_VIEW') or not loopback:
            abort(404)
        return send_from_directory(ROOT / 'frontend', 'admin-farmers.html')

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'same-origin'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        if response.content_type.startswith('application/json'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.errorhandler(ValidationError)
    def validation_error(error):
        return jsonify(error=str(error), fields=error.fields), 400

    @app.errorhandler(HTTPException)
    def http_error(error):
        return jsonify(error=error.description), error.code

    @app.errorhandler(Exception)
    def server_error(error):
        # Log the exception type only; DB exceptions may include connection details.
        app.logger.error('Request failed (%s). Check database/model availability.', type(error).__name__)
        return jsonify(error='The request could not be completed. Check system status and the local server console.'), 500

    return app


if __name__ == '__main__':
    from waitress import serve
    application = create_app()
    port = int(os.getenv('PORT', '5000'))
    print(f"Database: {application.extensions['store'].kind} — {application.extensions['store'].message}", flush=True)
    print(f'Krishi Mitra: http://127.0.0.1:{port}  |  Stop with Ctrl+C', flush=True)
    serve(application, host='127.0.0.1', port=port, threads=4)
