"""Krishi Mitra local demonstration application."""
