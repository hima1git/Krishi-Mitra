import math

from backend.catalog import DISTRICTS, SEASONS, SCENARIOS, PREVIOUS_CROPS

NUMERIC_BOUNDS = {
    'farm_size': (0.01, 10000), 'nitrogen': (0, 300),
    'phosphorus': (0, 200), 'potassium': (0, 400), 'ph': (0, 14),
    'temperature': (-10, 55), 'rainfall': (0, 4000),
    'humidity': (0, 100), 'soil_moisture': (0, 100),
}
CATEGORIES = {'district': DISTRICTS, 'season': SEASONS,
              'irrigation': ['yes', 'no'], 'previous_crop': PREVIOUS_CROPS,
              'scenario': SCENARIOS}


class ValidationError(ValueError):
    def __init__(self, fields):
        super().__init__('Please correct the highlighted fields.')
        self.fields = fields


def validate_profile(payload):
    if not isinstance(payload, dict):
        raise ValidationError({'body': 'A JSON object is required.'})
    clean, errors = {}, {}
    for field, (low, high) in NUMERIC_BOUNDS.items():
        raw = payload.get(field)
        try:
            if raw is None or isinstance(raw, bool):
                raise ValueError
            value = float(raw)
            if not math.isfinite(value) or not low <= value <= high:
                raise ValueError
            clean[field] = value
        except (ValueError, TypeError):
            errors[field] = f'Enter a number between {low} and {high}.'
    for field, choices in CATEGORIES.items():
        if payload.get(field) not in choices:
            errors[field] = 'Choose one of the supported options.'
        else:
            clean[field] = payload[field]
    if errors:
        raise ValidationError(errors)
    return clean
