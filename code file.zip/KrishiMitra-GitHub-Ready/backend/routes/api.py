import json
import ipaddress
import platform
import secrets
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from pathlib import Path

from flask import Blueprint, abort, current_app, jsonify, request, session

from backend.catalog import CROPS, DISCLAIMER, DISTRICTS, NON_TARGET_CROP_NAMES, SEASONS
from backend.services.dashboard import grouped_importances
from backend.services.regional_data import district_references, resolve_soil_inputs
from backend.services.enso import scenario_for
from backend.utils.validation import CATEGORIES, NUMERIC_BOUNDS, validate_profile, ValidationError

api = Blueprint('api', __name__, url_prefix='/api')


def components():
    return current_app.extensions['store'], current_app.extensions['recommender']


def user_id():
    if 'visitor_key' not in session:
        session['visitor_key'] = secrets.token_hex(24)
    return components()[0].user(session['visitor_key'])


def local_admin_allowed():
    try:
        return (current_app.config.get('LOCAL_ADMIN_VIEW', False)
                and ipaddress.ip_address(request.remote_addr or '').is_loopback)
    except ValueError:
        return False


@api.before_request
def protect_writes():
    if request.method == 'POST':
        supplied = request.headers.get('X-CSRF-Token', '')
        expected = session.get('csrf_token', '')
        if not expected or not secrets.compare_digest(supplied, expected):
            return jsonify(error='Session token missing or expired. Refresh the page and try again.'), 403
        if not request.is_json:
            return jsonify(error='Send a JSON request body.'), 415


@api.get('/health')
def health():
    store, model = components()
    healthy = store.healthy()
    ready = healthy and model.bundle is not None
    return jsonify(backend_status='ok' if ready else 'degraded', python_version=platform.python_version(),
                   database={'type': store.kind, 'status': 'ok' if healthy else 'unavailable', 'message': store.message},
                   ml_model={'status': model.status, 'data_source': model.bundle['data_source'] if model.bundle else None}), 200 if ready else 503


@api.get('/system-info')
def system_info():
    store, model = components()
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(32)
    metrics_path = Path(current_app.config['MODEL_PATH']).with_name('metrics.json')
    metrics = None
    if metrics_path.exists():
        try:
            report = json.loads(metrics_path.read_text(encoding='utf-8'))
            if model.bundle and report.get('model_version') == model.bundle['version']:
                metrics = {k: report.get(k) for k in ['accuracy', 'precision_macro', 'recall_macro', 'f1_macro', 'test_rows']}
        except (ValueError, OSError):
            pass
    database_ok = store.healthy()
    history = store.history(user_id()) if database_ok else []
    return jsonify(name='Krishi Mitra', disclaimer=DISCLAIMER, csrf_token=session['csrf_token'],
                   database={'type': store.kind, 'message': store.message},
                   model_status=model.status, model_version=model.bundle['version'] if model.bundle else None,
                   weights={'random_forest': model.rf_weight, 'collaborative': model.cf_weight},
                   metrics=metrics, history=history, history_available=database_ok,
                   crop_count=len(CROPS), feature_importances=grouped_importances(model.bundle),
                   model_data_source=model.bundle['data_source'] if model.bundle else None,
                   regional_reference=district_references())


@api.get('/crops')
def crops():
    return jsonify(crops=[{k: v for k, v in c.items() if k != 'center'} for c in CROPS],
                   previous_crops=[dict(name='None', marathi_name='नाही', hindi_name='नहीं')]
                                  + [dict(name=name, **next(({'marathi_name': crop.get('marathi_name'), 'hindi_name': crop.get('hindi_name')}
                                                            for crop in CROPS if crop['name'] == name),
                                                           NON_TARGET_CROP_NAMES.get(name, {})))
                                     for name in ['Cotton'] + [c['name'] for c in CROPS]],
                   source='Illustrative demo profiles, not verified agricultural requirements.')


@api.get('/weather/<district>')
def weather(district):
    """Return IMD observations/forecast with provenance, or an explicit unavailable state."""
    canonical = next((name for name in DISTRICTS if name.casefold() == district.casefold()), None)
    if canonical is None:
        raise ValidationError({'district': 'Choose one of the supported Vidarbha districts.'})
    result = current_app.extensions['weather'].for_district(canonical)
    reference = district_references()
    values = reference['districts'][canonical]
    retrieved = datetime.now(timezone.utc).isoformat(timespec='seconds')
    result['district_default'] = {
        'district': canonical, 'variable': 'historical rainfall normal',
        'annual_rainfall_mm': values['annual_rainfall_mm'],
        'monsoon_rainfall_mm': values['monsoon_rainfall_mm'],
        'source': 'ICAR-CRIDA district contingency plan', 'source_url': values['source_url'],
        'source_section': values['source_section'], 'page': values['page'],
        'observation_time': None, 'reference_period': None, 'retrieved_at': retrieved,
        'data_type': 'historical', 'fallback': True,
        'status': 'HISTORICAL — reference only; not current weather or a farm measurement.',
    }
    return jsonify(result)


@api.get('/enso')
def enso():
    """Current official global outlook reference; it is not local rainfall data."""
    return jsonify(current_app.extensions['enso'].official_outlook())


@api.get('/admin/farmers')
def local_admin_data():
    if not local_admin_allowed():
        abort(404)
    store = current_app.extensions['store']
    return jsonify(database_type=store.kind, records=store.admin_records())


@api.route('/profile', methods=['GET', 'PUT'])
def farmer_profile():
    store, _ = components()
    uid = user_id()
    if request.method == 'GET':
        saved = store.farmer_profile(uid)
        return jsonify(profile=saved['profile'] if saved else None,
                       updated_at=saved['updated_at'] if saved else None)
    body = request.get_json()
    if not isinstance(body, dict):
        raise ValidationError({'body': 'A JSON object is required.'})
    errors = {}
    allowed = {'name', 'village', 'taluka', 'district', 'state', 'total_land', 'land_unit',
               'irrigated_area', 'rainfed_area', 'water_source', 'soil_type', 'nitrogen',
               'phosphorus', 'potassium', 'current_crops', 'previous_crops',
               'preferred_crops', 'season', 'latitude', 'longitude',
               'temperature', 'rainfall', 'humidity'}
    if set(body) - allowed:
        errors['body'] = 'The profile contains unsupported fields.'
    cleaned = {}
    for key, limit in [('name', 100), ('village', 100), ('taluka', 100)]:
        value = body.get(key, '')
        if not isinstance(value, str) or len(value.strip()) > limit:
            errors[key] = f'Enter up to {limit} characters.'
        else:
            cleaned[key] = value.strip()
    district = body.get('district', '')
    if district and district not in DISTRICTS:
        errors['district'] = 'Choose one of the supported Vidarbha districts.'
    cleaned['district'] = district
    state = body.get('state', 'Maharashtra')
    if state != 'Maharashtra':
        errors['state'] = 'This profile is currently scoped to Maharashtra.'
    cleaned['state'] = 'Maharashtra'
    unit = body.get('land_unit', 'acres')
    if unit not in ('acres', 'hectares'):
        errors['land_unit'] = 'Choose acres or hectares.'
    cleaned['land_unit'] = unit
    for key in ('total_land', 'irrigated_area', 'rainfed_area'):
        value = body.get(key)
        if value in (None, ''):
            cleaned[key] = None
        else:
            try:
                number = float(value)
                if isinstance(value, bool) or not 0 <= number <= 10000:
                    raise ValueError
                cleaned[key] = number
            except (ValueError, TypeError):
                errors[key] = 'Enter a value from 0 to 10,000, or leave it blank.'
    if all(cleaned.get(k) is not None for k in ('total_land', 'irrigated_area', 'rainfed_area')):
        if cleaned['irrigated_area'] + cleaned['rainfed_area'] > cleaned['total_land'] + 1e-8:
            errors['irrigated_area'] = 'Irrigated and rainfed area cannot exceed total land.'
    for key, limit in [('water_source', 80), ('soil_type', 80)]:
        value = body.get(key, '')
        if not isinstance(value, str) or len(value.strip()) > limit:
            errors[key] = f'Enter up to {limit} characters.'
        else:
            cleaned[key] = value.strip()
    for key in ('nitrogen', 'phosphorus', 'potassium'):
        value = body.get(key)
        if value in (None, ''):
            cleaned[key] = None
        else:
            try:
                number = float(value)
                if isinstance(value, bool) or not 0 <= number <= 400:
                    raise ValueError
                cleaned[key] = number
            except (ValueError, TypeError):
                errors[key] = 'Enter a soil test value from 0 to 400, or leave it blank.'
    for key in ('temperature', 'rainfall', 'humidity'):
        value = body.get(key)
        if value in (None, ''):
            cleaned[key] = None
        else:
            try:
                number = float(value)
                low, high = NUMERIC_BOUNDS[key]
                if isinstance(value, bool) or not low <= number <= high:
                    raise ValueError
                cleaned[key] = number
            except (ValueError, TypeError):
                errors[key] = f'Enter a local value from {NUMERIC_BOUNDS[key][0]} to {NUMERIC_BOUNDS[key][1]}, or leave it blank.'
    valid_crops = {crop['name'] for crop in CROPS} | {'Cotton'}
    for key in ('current_crops', 'previous_crops', 'preferred_crops'):
        value = body.get(key, [])
        if not isinstance(value, list) or any(item not in valid_crops for item in value):
            errors[key] = 'Choose crops from the supported crop list.'
        else:
            cleaned[key] = list(dict.fromkeys(value))[:20]
    season = body.get('season', '')
    if season and season not in SEASONS:
        errors['season'] = 'Choose a supported farming season.'
    cleaned['season'] = season
    for key, low, high in [('latitude', -90, 90), ('longitude', -180, 180)]:
        value = body.get(key)
        if value in (None, ''):
            cleaned[key] = None
        else:
            try:
                number = float(value)
                if isinstance(value, bool) or not low <= number <= high:
                    raise ValueError
                cleaned[key] = number
            except (ValueError, TypeError):
                errors[key] = f'Enter a value from {low} to {high}, or leave it blank.'
    if (cleaned.get('latitude') is None) != (cleaned.get('longitude') is None):
        errors['latitude'] = 'Enter both coordinates or leave both blank.'
    if errors:
        raise ValidationError(errors)
    if any(cleaned.get(key) is not None for key in ('temperature', 'rainfall', 'humidity')):
        cleaned['weather_updated_at'] = datetime.now(ZoneInfo('Asia/Kolkata')).isoformat(timespec='minutes')
    store.save_farmer_profile(uid, cleaned)
    return jsonify(status='saved', profile=cleaned)


@api.post('/recommend')
def recommend():
    store, model = components()
    if not model.bundle:
        return jsonify(error='Model unavailable. Run setup or retrain, then restart.'), 503
    payload = request.get_json()
    scenario_key = payload.get('climate_scenario', 'normal') if isinstance(payload, dict) else 'normal'
    if not isinstance(payload, dict) or set(payload) - set(NUMERIC_BOUNDS) - set(CATEGORIES) - {'climate_scenario', 'field_sources'}:
        raise ValidationError({'body': 'The recommendation contains unsupported fields.'})
    submitted_sources = payload.get('field_sources', {})
    if (not isinstance(submitted_sources, dict)
            or set(submitted_sources) - {'temperature', 'rainfall', 'humidity'}
            or any(value not in ('example', 'farmer_provided') for value in submitted_sources.values())):
        raise ValidationError({'field_sources': 'Weather value sources must be example or farmer_provided.'})
    field_sources = {key: submitted_sources.get(key, 'farmer_provided')
                     for key in ('temperature', 'rainfall', 'humidity')}
    try:
        scenario = scenario_for(scenario_key, payload.get('district'))
    except ValueError as error:
        raise ValidationError({'climate_scenario': str(error)}) from error
    model_payload = dict(payload)
    model_payload.pop('climate_scenario', None)
    model_payload.pop('field_sources', None)
    resolved, provenance, assumptions = resolve_soil_inputs(model_payload, model.bundle)
    for field, source in field_sources.items():
        if source == 'example':
            provenance[field] = {'kind': 'example_input', 'basis': 'illustrative example',
                                 'field': field, 'district': model_payload.get('district'),
                                 'explanation': 'Loaded from the explicit example-values control; this is not a measurement from a farmer.'}
    profile = validate_profile(resolved)
    uid = user_id()
    results, excluded = model.recommend(profile, uid, store.interactions())
    for crop in results:
        crop['climate_scenario'] = {
            'stress_level': scenario['stress_level'],
            'suitability_change': 'not_assessed',
            'consideration': 'No crop-specific suitability change is calculated: verified regional crop-response data are unavailable. Existing catalog water and drought labels are illustrative.',
        }
    # Preserve provenance inside the existing JSON snapshot; no schema migration.
    snapshot = dict(profile, _input_provenance=provenance, _data_assumptions=assumptions,
                    _climate_scenario=scenario, _field_sources=field_sources)
    recommendation_id = store.save_recommendation(uid, snapshot, results, model.bundle['version'])
    return jsonify(recommendation_id=recommendation_id, recommendations=results,
                   excluded=excluded, database_type=store.kind, disclaimer=DISCLAIMER,
                   weights={'random_forest': model.rf_weight, 'collaborative': model.cf_weight},
                   input_provenance=provenance, data_assumptions=assumptions,
                   climate_scenario=scenario, field_sources=field_sources)


@api.post('/interactions')
def interaction():
    body = request.get_json()
    if not isinstance(body, dict):
        raise ValidationError({'body': 'A JSON object is required.'})
    if body.get('action') not in ('selected', 'accepted', 'rejected'):
        raise ValidationError({'action': 'Choose selected, accepted, or rejected.'})
    for field in ('recommendation_id', 'crop_id'):
        if type(body.get(field)) is not int or body[field] <= 0:
            raise ValidationError({field: 'A positive integer is required.'})
    try:
        components()[0].save_interaction(user_id(), body['recommendation_id'], body['crop_id'], body['action'])
    except ValueError as exc:
        return jsonify(error=str(exc)), 404
    return jsonify(status='saved', message='Feedback saved. Collaborative scores need sufficient shared history.')
