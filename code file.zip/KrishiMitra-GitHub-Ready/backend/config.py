import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env')


def settings():
    return {
        'DB_MODE': os.getenv('DB_MODE', 'auto').lower(),
        'SQLITE_PATH': os.getenv('SQLITE_PATH', str(ROOT / 'instance' / 'krishimitra.db')),
        'MYSQL_HOST': os.getenv('MYSQL_HOST', '127.0.0.1'),
        'MYSQL_PORT': int(os.getenv('MYSQL_PORT', '3306')),
        'MYSQL_DATABASE': os.getenv('MYSQL_DATABASE', ''),
        'MYSQL_USER': os.getenv('MYSQL_USER', ''),
        'MYSQL_PASSWORD': os.getenv('MYSQL_PASSWORD', ''),
        'MODEL_PATH': str(ROOT / 'ml' / 'models' / 'random_forest.joblib'),
        'IMD_API_AUTH_HEADER': os.getenv('IMD_API_AUTH_HEADER', '').strip(),
        'IMD_API_AUTH_VALUE': os.getenv('IMD_API_AUTH_VALUE', ''),
        'IMD_API_TIMEOUT': float(os.getenv('IMD_API_TIMEOUT', '5')),
        'IMD_CACHE_SECONDS': int(os.getenv('IMD_CACHE_SECONDS', '900')),
        # Explicit opt-in; the admin viewer also rejects non-loopback clients.
        'LOCAL_ADMIN_VIEW': os.getenv('LOCAL_ADMIN_VIEW', '').strip().lower() in ('1', 'true', 'yes'),
        'RF_WEIGHT': float(os.getenv('RF_WEIGHT', '0.8')),
        'CF_WEIGHT': float(os.getenv('CF_WEIGHT', '0.2')),
        'MAX_CONTENT_LENGTH': 16384,
        'SESSION_COOKIE_HTTPONLY': True,
        'SESSION_COOKIE_SAMESITE': 'Strict',
    }
