"""Fail-closed adapter for official IMD district feeds.

The official APIs return district-wide lists. Each response is filtered to the
requested district before any value is exposed; no station or district value is
reused for another district. IMD authentication remains required.
"""
from __future__ import annotations

import json
import math
import threading
import time
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class IMDWeatherService:
    BASE_URL = 'https://api.imd.gov.in/api/v1'
    SOURCES = {
        'district_rainfall': '/districtrainfall',
        'district_forecast': '/state_district_rainfall_forecast',
        'district_warnings': '/districtwarning',
        'aws_observations': '/aws_data?sid=21',
    }

    def __init__(self, config, fetcher=None, clock=None):
        self.header = config.get('IMD_API_AUTH_HEADER', '').strip()
        self.auth_value = config.get('IMD_API_AUTH_VALUE', '')
        self.timeout = config.get('IMD_API_TIMEOUT', 5)
        self.cache_seconds = max(0, config.get('IMD_CACHE_SECONDS', 900))
        self.fetcher = fetcher or self._fetch
        self.clock = clock or time.monotonic
        self._cache = {}
        self._lock = threading.Lock()

    def for_district(self, district):
        sources = {name: self.BASE_URL + path for name, path in self.SOURCES.items()}
        if not self.header or not self.auth_value:
            return self._unavailable(district, 'IMD data currently unavailable. Authorized IMD API access is not configured.', sources)
        now = self.clock()
        with self._lock:
            cached = self._cache.get(district)
            if cached and now - cached[0] < self.cache_seconds:
                return dict(cached[1])
        try:
            payloads = {name: self.fetcher(url, self.header, self.auth_value, self.timeout)
                        for name, url in sources.items()}
        except (HTTPError, URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError):
            return self._unavailable(district, 'IMD data currently unavailable. Check authorized API access and try again.', sources)

        rainfall_row = self._district_row(payloads['district_rainfall'], district, ('District', 'DISTRICT'))
        forecast_row = self._district_row(payloads['district_forecast'], district, ('District', 'DISTRICT'))
        warning_row = self._district_row(payloads['district_warnings'], district, ('District', 'DISTRICT'))
        aws_row = self._district_row(payloads['aws_observations'], district, ('DISTRICT', 'District'))
        rainfall = self._number(rainfall_row, 'Daily Actual')
        rainfall_time = (rainfall_row or {}).get('Date')
        observed = self._observation(aws_row)
        if rainfall is not None:
            observed['rainfall_mm_daily'] = rainfall
            observed['rainfall_observation_date'] = rainfall_time
        if not (observed or forecast_row or warning_row):
            return self._unavailable(district, 'IMD responded, but no validated record matched the selected district. No measurements are shown.', sources,
                                     status='unavailable')

        retrieved = datetime.now(timezone.utc).isoformat(timespec='seconds')
        result = {
            'status': 'available', 'district': district, 'observations': observed or None,
            'rainfall': rainfall, 'forecast': self._forecast(forecast_row),
            'warnings': self._warnings(warning_row), 'sources': sources,
            'source': 'India Meteorological Department (IMD)',
            'data_type': 'observed/forecast', 'retrieved_at': retrieved,
            'observation_time': self._observation_time(aws_row) or rainfall_time,
            'model_input': False,
            'message': f'Only records matching {district} are shown. These readings are not Random Forest inputs.',
        }
        with self._lock:
            self._cache[district] = (self.clock(), result)
        return result

    @staticmethod
    def _items(payload):
        if isinstance(payload, list):
            return payload
        if isinstance(payload, dict):
            if isinstance(payload.get('data'), list):
                return payload['data']
            return [payload]
        return []

    @classmethod
    def _district_row(cls, payload, district, keys):
        normalize = lambda value: ' '.join(str(value or '').replace('_', ' ').split()).casefold()
        wanted = normalize(district)
        return next((row for row in cls._items(payload)
                     if isinstance(row, dict) and any(normalize(row.get(key)) == wanted for key in keys)), None)

    @staticmethod
    def _number(row, key):
        if not row:
            return None
        try:
            value = float(str(row.get(key, '')).strip())
            return value if math.isfinite(value) else None
        except (TypeError, ValueError):
            return None

    @classmethod
    def _observation(cls, row):
        if not row:
            return {}
        fields = {'temperature_c': 'CURR_TEMP', 'humidity_percent': 'RH',
                  'wind_speed_kmh': 'WIND_SPEED', 'wind_direction_degrees': 'WIND_DIRECTION'}
        result = {target: cls._number(row, source) for target, source in fields.items()}
        result = {key: value for key, value in result.items() if value is not None}
        for key in ('STATION', 'DATE', 'TIME', 'WEATHER_CODE'):
            if row.get(key) is not None:
                result[key.lower()] = row[key]
        return result

    @staticmethod
    def _observation_time(row):
        if not row:
            return None
        date, clock = row.get('DATE'), row.get('TIME')
        return f'{date} {clock}'.strip() if date or clock else None

    @staticmethod
    def _forecast(row):
        if not row:
            return None
        days = []
        for day in range(1, 6):
            distribution = row.get(f'day{day}_distribution')
            percentage = row.get(f'day{day}_distribution_percentage')
            if distribution is not None or percentage is not None:
                days.append({'day': day, 'distribution': distribution,
                             'distribution_percentage': percentage,
                             'color': row.get(f'day{day}_color')})
        return {'issued': row.get('date_obs'), 'days': days} if days else None

    @staticmethod
    def _warnings(row):
        if not row:
            return None
        return {key: value for key, value in row.items()
                if key.lower().startswith('day') or key in ('Date', 'UTC', 'District')}

    def _fetch(self, url, header, value, timeout):
        request = Request(url, headers={header: value, 'Accept': 'application/json'})
        with urlopen(request, timeout=timeout) as response:
            if response.status != 200:
                raise URLError('IMD request failed')
            return json.loads(response.read().decode('utf-8'))

    @staticmethod
    def _unavailable(district, message, sources, status='unavailable'):
        return {
            'status': status, 'district': district, 'observations': None,
            'rainfall': None, 'forecast': None, 'warnings': None,
            'sources': sources, 'source': 'India Meteorological Department (IMD)',
            'data_type': 'unavailable', 'retrieved_at': None,
            'observation_time': None, 'model_input': False, 'message': message,
        }
