"""Sourced reference context and explicit missing-input provenance.

Rainfall reference tables are display-only. No agricultural coefficient is inferred.
Only reviewed, unit-compatible numeric entries may enter the documented defaults
registry. It is intentionally empty until usable soil statistics are obtained.
"""
import json
import math
from pathlib import Path

from backend.config import ROOT
from backend.utils.validation import CATEGORIES, NUMERIC_BOUNDS, ValidationError

REFERENCE = json.loads((ROOT / 'backend/data/vidarbha_reference.json').read_text(encoding='utf-8'))
SOIL_FIELDS = {
    'nitrogen': ('Soil nitrogen (N)', 'kg/ha'),
    'phosphorus': ('Soil phosphorus (P)', 'kg/ha'),
    'potassium': ('Soil potassium (K)', 'kg/ha'),
    'ph': ('Soil pH', 'pH'),
    'soil_moisture': ('Soil moisture', '%'),
}


def district_references():
    return {
        **{key: REFERENCE[key] for key in ['region', 'reviewed_on', 'source_title', 'notice', 'quality_note', 'soil_default_notice']},
        'districts': {
            district: dict(values, source_url=REFERENCE['source_base'] + district + '.pdf',
                           source_section=REFERENCE['source_section'], reference_period=None)
            for district, values in REFERENCE['districts'].items()
        },
    }


def compatible_documented_value(entry, field):
    """Reject incomplete/incompatible source entries rather than guessing units."""
    if not isinstance(entry, dict):
        return False
    low, high = NUMERIC_BOUNDS[field]
    value = entry.get('value')
    return (type(value) in (int, float) and math.isfinite(value) and low <= value <= high
            and entry.get('unit') == SOIL_FIELDS[field][1]
            and entry.get('reviewed_for_model_input') is True
            and all(entry.get(k) for k in ['source_url', 'period', 'method', 'scope']))


def resolve_soil_inputs(payload, bundle, reference=None):
    """User > documented district > documented region > fitted training median.

Only missing optional soil inputs are filled. Zero stays zero; malformed or
out-of-range supplied values still pass through the existing validator and fail.
The model and fitted preprocessing objects are never modified.
"""
    if not isinstance(payload, dict):
        raise ValidationError({'body': 'A JSON object is required.'})
    district = payload.get('district')
    if district not in CATEGORIES['district']:
        raise ValidationError({'district': 'Choose one of the supported options.'})
    registry = (reference or REFERENCE)['soil_defaults']
    resolved = dict(payload)
    provenance = {field: {'kind': 'user_provided'} for field in [*NUMERIC_BOUNDS, *CATEGORIES]}
    assumptions = []
    for field, (label, unit) in SOIL_FIELDS.items():
        raw = payload.get(field)
        missing = raw is None or (isinstance(raw, str) and not raw.strip())
        if not missing:
            continue
        estimate = None
        for tier, scope, entries in [
            ('documented_district_estimate', district, registry['districts'].get(district, {})),
            ('documented_regional_estimate', 'Vidarbha', registry['vidarbha']),
        ]:
            entry = entries.get(field)
            if compatible_documented_value(entry, field):
                estimate = dict(kind='estimated_default', basis='documented', tier=tier,
                                scope=scope, value=entry['value'], source_url=entry['source_url'],
                                period=entry['period'], method=entry['method'],
                                explanation=f'{label} was not provided. A documented {scope} aggregate estimate was used; this is not a soil test from your farm.')
                break
        if estimate is None:
            # Use actual per-column fitted medians, never invented district constants.
            if bundle is None:
                raise ValidationError({field: 'Default unavailable until the model is loaded.'})
            preprocessing = bundle['pipeline'].named_steps['preprocess']
            numeric_columns = next(columns for name, _, columns in preprocessing.transformers_ if name == 'numeric')
            imputer = preprocessing.named_transformers_['numeric'].named_steps['impute']
            value = float(imputer.statistics_[list(numeric_columns).index(field)])
            low, high = NUMERIC_BOUNDS[field]
            if not math.isfinite(value) or not low <= value <= high:
                raise ValidationError({field: 'No usable default; please provide a measured value.'})
            estimate = dict(kind='estimated_default', basis='synthetic', tier='prototype_training_median',
                            scope='Current generated demonstration training partition; not a regional statistic', value=value,
                            source_model_version=bundle['version'],
                            method='Median fitted by the saved numeric SimpleImputer on training rows only',
                            explanation=f'{label} was not provided. No compatible documented default is enabled for {district} or Vidarbha. A median from generated demonstration training examples was used as a prototype estimate, not a field measurement.')
        estimate.update(field=field, label=label, unit=unit, district=district)
        resolved[field] = estimate['value']
        provenance[field] = estimate
        assumptions.append(estimate)
    return resolved, provenance, assumptions
