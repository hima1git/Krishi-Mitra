"""User-based cosine CF on real local interactions; no seeded farmer behavior."""
from collections import defaultdict
import math

ACTION_SCORES = {'selected': .65, 'accepted': 1.0, 'rejected': 0.0}


def collaborative_score(user_id, crop_id, interactions):
    # Average repeated observations so prolific users do not count as many neighbors.
    grouped = defaultdict(list)
    for row in interactions:
        grouped[(row['user_id'], row['crop_id'])].append(ACTION_SCORES[row['action']])
    profiles = defaultdict(dict)
    for (user, crop), values in grouped.items():
        profiles[user][crop] = 2 * (sum(values) / len(values)) - 1
    target = profiles.get(user_id, {})
    weighted, total_weight, support = 0.0, 0.0, 0
    for neighbor, ratings in profiles.items():
        if neighbor == user_id or crop_id not in ratings:
            continue
        common = (target.keys() & ratings.keys()) - {crop_id}
        if len(common) < 2:
            continue
        numerator = sum(target[c] * ratings[c] for c in common)
        denominator = math.sqrt(sum(target[c] ** 2 for c in common) * sum(ratings[c] ** 2 for c in common))
        if not denominator:
            continue
        similarity = numerator / denominator
        if similarity <= 0:
            continue
        weight = similarity * len(common) / (len(common) + 2)
        weighted += weight * ratings[crop_id]
        total_weight += weight
        support += 1
    if support < 2 or total_weight == 0:
        return {'score': .5, 'mode': 'neutral_fallback', 'neighbors': support}
    return {'score': max(0, min(1, (weighted / total_weight + 1) / 2)),
            'mode': 'collaborative', 'neighbors': support}
