"""Separate official global ENSO outlook metadata from hypothetical scenarios."""
from __future__ import annotations

from html.parser import HTMLParser
import json
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

CONFIG_PATH = Path(__file__).resolve().parents[1] / 'data' / 'climate_scenarios.json'
NOAA_DISCUSSION = 'https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso_advisory/ensodisc.html'
NOAA_RONI = 'https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso/roni/'


class _PageText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)


class _TableRows(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows, self.row, self.cell = [], None, None

    def handle_starttag(self, tag, attrs):
        if tag == 'tr':
            self.row = []
        elif tag in ('td', 'th') and self.row is not None:
            self.cell = ''

    def handle_data(self, data):
        if self.cell is not None:
            self.cell += data

    def handle_endtag(self, tag):
        if tag in ('td', 'th') and self.row is not None and self.cell is not None:
            self.row.append(self.cell.strip())
            self.cell = None
        elif tag == 'tr' and self.row is not None:
            self.rows.append(self.row)
            self.row = None


class ENSOService:
    def __init__(self, fetcher=None, clock=None, cache_seconds=3600):
        self.fetcher = fetcher or self._fetch
        self.clock = clock or time.time
        self.cache_seconds = cache_seconds
        self._cached_at = 0
        self._cached = None

    @staticmethod
    def scenarios():
        return json.loads(CONFIG_PATH.read_text(encoding='utf-8'))

    def official_outlook(self):
        now = self.clock()
        if self._cached and now - self._cached_at < self.cache_seconds:
            return dict(self._cached)
        try:
            html = self.fetcher(NOAA_DISCUSSION, 8)
            parser = _PageText()
            parser.feed(html)
            text = ' '.join(' '.join(parser.parts).split())
            issue = re.search(r'(?:issued\s+by\s+CLIMATE PREDICTION CENTER/NCEP/NWS\s+)?(\d{1,2}\s+[A-Z][a-z]+\s+\d{4})', text, re.I)
            if not issue:
                issue = re.search(r'Issued\s+([A-Z][a-z]+\s+\d{4})', text, re.I)
            if not issue:
                raise ValueError('NOAA discussion issue date unavailable')
            alert = re.search(r'ENSO Alert System Status:\s*(.*?)(?:Synopsis:|$)', text, re.I)
            synopsis = re.search(r'Synopsis:\s*(.*?)(?:This discussion is a consolidated effort|The next ENSO Diagnostics Discussion|$)', text, re.I)
            if not alert:
                raise ValueError('NOAA alert status unavailable')
            alert_status = alert.group(1).strip(' .;')
            summary = synopsis.group(1).strip() if synopsis else ''
            state = self._state_from_official_text(alert_status, summary)
            if state == 'unavailable':
                raise ValueError('NOAA discussion does not identify an ENSO state')
            trend = next((word for word in ('strengthening', 'weakening', 'persisting', 'developing')
                          if re.search(r'\b' + word + r'\b', summary, re.I)), None)
            forecast_strength = re.search(r'(?:chance|probability) of (?:a )?(weak|moderate|strong|very strong) event', summary, re.I)
            probability = re.search(r'(greater than\s+)?(\d{1,3})% chance of (?:a )?(?:weak|moderate|strong|very strong) event', summary, re.I)
            data = {'status': 'available', 'state': state,
                    'alert_status': alert_status, 'trend': trend,
                    'forecast_strength': forecast_strength.group(1).title() if forecast_strength else None,
                    'forecast_probability': (('>' if probability.group(1) else '') + probability.group(2) + '%') if probability else None,
                    'name': 'Official NOAA CPC ENSO Diagnostic Discussion',
                    'issued': issue.group(1), 'source': NOAA_DISCUSSION,
                    'message': 'Global ENSO status; it is not a Vidarbha rainfall forecast. Regional impacts vary.',
                    'retrieved_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(now))}
        except Exception:
            data = {'status': 'unavailable', 'state': 'unavailable', 'alert_status': None,
                    'trend': None, 'forecast_strength': None, 'forecast_probability': None,
                    'name': 'Official NOAA CPC ENSO Diagnostic Discussion',
                    'issued': None, 'source': NOAA_DISCUSSION,
                    'message': 'ENSO status unavailable. The official NOAA discussion could not be retrieved; no current status is inferred.',
                    'retrieved_at': None}
        try:
            roni_page = self.fetcher(NOAA_RONI, 8)
            data['observed_enso'] = self._latest_roni(roni_page, now)
        except Exception:
            data['observed_enso'] = {'status': 'unavailable', 'classification': None,
                                     'source': NOAA_RONI,
                                     'message': 'The latest published global RONI observation could not be retrieved.'}
        self._cached, self._cached_at = data, now
        return dict(data)

    @staticmethod
    def _latest_roni(html, now):
        parser = _TableRows()
        parser.feed(html)
        periods = ['DJF', 'JFM', 'FMA', 'MAM', 'AMJ', 'MJJ', 'JJA', 'JAS', 'ASO', 'SON', 'OND', 'NDJ']
        end_months = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 1]
        latest = []
        for row in parser.rows:
            if not row or not re.fullmatch(r'\d{4}', row[0]):
                continue
            year = int(row[0])
            values = row[1:]
            for index, raw in enumerate(values[:12]):
                try:
                    value = float(raw)
                except (TypeError, ValueError):
                    continue
                period_year = year + (1 if index == 11 else 0)
                month = end_months[index]
                if (period_year, month) <= (datetime.fromtimestamp(now, timezone.utc).year,
                                           datetime.fromtimestamp(now, timezone.utc).month - 1):
                    latest.append((period_year, month, periods[index], value))
        if not latest:
            raise ValueError('RONI table has no completed observation')
        latest.sort(key=lambda item: (item[0], item[1]))
        last = latest[-1]
        recent = latest[-5:]
        consecutive = len(recent) == 5 and all(
            (previous[0] + (1 if previous[1] == 12 else 0), 1 if previous[1] == 12 else previous[1] + 1)
            == (current[0], current[1]) for previous, current in zip(recent, recent[1:]))
        values = [entry[3] for entry in recent]
        warm = consecutive and all(value > 0.5 for value in values)
        cold = consecutive and all(value < -0.5 for value in values)
        classification = ('El Niño' if warm else 'La Niña' if cold else 'Neutral / transition by the latest five published RONI periods')
        magnitude = abs(last[3])
        strength = ('Very Strong' if magnitude >= 2.0 else 'Strong' if magnitude >= 1.5 else
                    'Moderate' if magnitude >= 1.0 else 'Weak' if magnitude >= 0.5 else 'Below weak threshold')
        return {'status': 'available', 'classification': classification,
                'strength': strength,
                'index_name': 'Relative Oceanic Niño Index (RONI)',
                'value_c': last[3], 'period': f'{last[2]} {last[0]}',
                'source': 'https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso/roni/',
                'message': 'Global Pacific ENSO indicator only; strength bands use NOAA RONI half-degree thresholds and do not predict district rainfall in Vidarbha. Recent values can be revised.'}

    @staticmethod
    def _state_from_official_text(alert_status, summary):
        text = f'{alert_status} {summary}'.casefold()
        if 'el niño advisory' in text or 'el nino advisory' in text:
            return 'El Niño'
        if 'la niña advisory' in text or 'la nina advisory' in text:
            return 'La Niña'
        if re.search(r'enso[- ]neutral (?:conditions )?(?:are|were) present', text):
            return 'Neutral'
        if 'el niño' in alert_status.casefold() or 'el nino' in alert_status.casefold():
            return 'El Niño'
        if 'la niña' in alert_status.casefold() or 'la nina' in alert_status.casefold():
            return 'La Niña'
        return 'unavailable'

    @staticmethod
    def _fetch(url, timeout):
        request = Request(url, headers={'User-Agent': 'KrishiMitra/1.0 (local farmer decision-support project)'})
        with urlopen(request, timeout=timeout) as response:
            if response.status != 200:
                raise URLError('NOAA outlook request failed')
            return response.read().decode('utf-8', errors='replace')


def scenario_for(key, district):
    config = ENSOService.scenarios()
    scenario = config['scenarios'].get(key)
    if scenario is None:
        raise ValueError('Choose a supported climate scenario.')
    return {'key': key, **scenario, 'district': district,
            'geographic_scope': config['geographic_scope'],
            'historical_basis': config['historical_basis'],
            'disclaimer': config['disclaimer']}
