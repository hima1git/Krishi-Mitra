"""Read dashboard information from the loaded forest, without retraining."""
from ml.preprocess import FEATURES

LABELS = {'farm_size': 'Farm size', 'nitrogen': 'Nitrogen (N)', 'phosphorus': 'Phosphorus (P)',
          'potassium': 'Potassium (K)', 'ph': 'Soil pH', 'temperature': 'Temperature',
          'rainfall': 'Rainfall', 'humidity': 'Humidity', 'soil_moisture': 'Soil moisture',
          'district': 'District', 'season': 'Season', 'irrigation': 'Irrigation',
          'previous_crop': 'Previous crop', 'scenario': 'Rainfall scenario'}


def grouped_importances(bundle):
    if bundle is None:
        return []
    pipeline = bundle['pipeline']
    names = pipeline.named_steps['preprocess'].get_feature_names_out()
    weights = pipeline.named_steps['forest'].feature_importances_
    grouped = {field: 0.0 for field in FEATURES}
    # Longest match ensures previous_crop_* belongs to previous_crop.
    fields = sorted(FEATURES, key=len, reverse=True)
    for name, weight in zip(names, weights):
        source_name = name.split('__', 1)[1]
        field = next(field for field in fields if source_name == field or source_name.startswith(field + '_'))
        grouped[field] += float(weight)
    return sorted([dict(feature=field, label=LABELS[field], importance=value)
                   for field, value in grouped.items()], key=lambda row: (-row['importance'], row['feature']))
