import math
from pathlib import Path

import joblib
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestClassifier

from backend.catalog import CROPS
from backend.services.collaborative import collaborative_score
from ml.preprocess import FEATURES


class Recommender:
    def __init__(self, config):
        self.rf_weight, self.cf_weight = config['RF_WEIGHT'], config['CF_WEIGHT']
        if not all(math.isfinite(x) and 0 <= x <= 1 for x in [self.rf_weight, self.cf_weight]) or not math.isclose(self.rf_weight + self.cf_weight, 1.0):
            raise ValueError('RF_WEIGHT and CF_WEIGHT must be finite, nonnegative, and sum to 1.')
        self.bundle = None
        self.status = 'missing; run setup or python -m ml.train_model'
        if Path(config['MODEL_PATH']).exists():
            try:
                candidate = joblib.load(config['MODEL_PATH'])
                if (candidate['features'] != FEATURES or candidate['sklearn_version'] != sklearn.__version__
                        or not isinstance(candidate['pipeline'].named_steps['forest'], RandomForestClassifier)):
                    raise ValueError('Invalid model schema')
                self.bundle = candidate
                self.status = 'ready'
            except Exception:
                self.status = 'unreadable or incompatible; retrain the model locally'

    def recommend(self, profile, user_id, interactions):
        if not self.bundle:
            raise RuntimeError('ML model unavailable. Run setup or retrain the model, then restart.')
        frame = pd.DataFrame([profile], columns=FEATURES)
        probabilities = self.bundle['pipeline'].predict_proba(frame)[0]
        classes = self.bundle['pipeline'].named_steps['forest'].classes_
        scores = dict(zip(classes, probabilities))
        ranked, excluded = [], []
        for crop in CROPS:
            if profile['season'] not in crop['seasons']:
                excluded.append({'crop': crop['name'], 'crop_marathi': crop['marathi_name'], 'crop_hindi': crop['hindi_name'], 'reason': 'Not in the selected season profile.'})
                continue
            if profile['previous_crop'] == crop['name']:
                excluded.append({'crop': crop['name'], 'crop_marathi': crop['marathi_name'], 'crop_hindi': crop['hindi_name'], 'reason': 'Previous crop excluded to suggest alternatives.'})
                continue
            if profile['scenario'] == 'severe_stress' and profile['irrigation'] == 'no' and crop['water'] == 'High':
                excluded.append({'crop': crop['name'], 'crop_marathi': crop['marathi_name'], 'crop_hindi': crop['hindi_name'], 'reason': 'High illustrative water need with severe stress and no irrigation.'})
                continue
            cf = collaborative_score(user_id, crop['id'], interactions)
            rf = float(scores.get(crop['name'], 0))
            final = self.rf_weight * rf + self.cf_weight * cf['score']
            reasons = [f"Included in the illustrative {profile['season']} crop list.",
                       f"Illustrative water need: {crop['water'].lower()}; illustrative drought tolerance: {crop['drought'].lower()}."]
            if profile['previous_crop'] != 'None':
                reasons.append(f"An alternative to your previous crop, {profile['previous_crop']}.")
            reasons.append('RF score is a class probability learned from generated demonstration examples, not a measured chance of crop success.')
            reasons.append('Insufficient shared interaction history: neutral CF score of 50%.' if cf['mode'] == 'neutral_fallback' else f"CF uses {cf['neighbors']} similar local users.")
            ranked.append(dict(crop_id=crop['id'], crop=crop['name'], display_name_en=crop.get('display_name_en', crop['name']), crop_marathi=crop['marathi_name'],
                               crop_hindi=crop['hindi_name'], scientific_name=crop['scientific_name'],
                               image=crop['image'], image_credit=crop.get('image_credit'), duration_days=crop.get('duration_days'), family=crop['family'],
                               random_forest_score=rf, collaborative_score=cf['score'], final_score=final,
                               collaborative_mode=cf['mode'], neighbor_count=cf['neighbors'],
                               water_requirement=crop['water'], drought_suitability=crop['drought'],
                               explanation=reasons))
        ranked.sort(key=lambda row: (-row['final_score'], row['crop']))
        return ranked[:5], excluded
