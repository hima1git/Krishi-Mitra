"""Small DB-API adapter. Fallback is decided once, before serving requests."""
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

import mysql.connector

from backend.catalog import CROPS
from backend.config import ROOT


class Store:
    def __init__(self, config):
        self.config = config
        mode = config['DB_MODE']
        if mode not in ('auto', 'sqlite', 'mysql'):
            raise ValueError('DB_MODE must be auto, mysql, or sqlite.')
        self.kind = 'sqlite'
        self.message = 'SQLite selected for local demonstration.'
        configured = bool(config['MYSQL_USER'] and config['MYSQL_DATABASE'])
        if mode != 'sqlite' and configured:
            try:
                connection = self._mysql()
                connection.close()
                self.kind = 'mysql'
                self.message = 'Connected to configured MySQL database.'
            except mysql.connector.Error:
                if mode == 'mysql':
                    raise RuntimeError('MySQL connection failed. Check the local .env configuration.') from None
                self.message = 'Configured MySQL is unavailable; using SQLite demo fallback.'
        elif mode == 'mysql':
            raise RuntimeError('MySQL mode requires MYSQL_USER and MYSQL_DATABASE in .env.')
        elif mode == 'auto':
            self.message = 'MySQL credentials are not configured; using SQLite demo fallback.'
        if self.kind == 'sqlite':
            Path(config['SQLITE_PATH']).parent.mkdir(parents=True, exist_ok=True)
        try:
            self.initialize()
        except mysql.connector.Error:
            if mode != 'auto' or self.kind != 'mysql':
                raise RuntimeError('MySQL schema initialization failed. Check database permissions locally.') from None
            self.kind = 'sqlite'
            self.message = 'MySQL schema initialization failed; using SQLite demo fallback.'
            Path(config['SQLITE_PATH']).parent.mkdir(parents=True, exist_ok=True)
            self.initialize()

    def _mysql(self):
        connection = mysql.connector.connect(
            host=self.config['MYSQL_HOST'], port=self.config['MYSQL_PORT'],
            user=self.config['MYSQL_USER'], password=self.config['MYSQL_PASSWORD'],
            database=self.config['MYSQL_DATABASE'], connection_timeout=3,
            charset='utf8mb4', autocommit=False)
        cursor = connection.cursor()
        try:
            cursor.execute("SET time_zone = '+00:00'")
        finally:
            cursor.close()
        return connection

    @contextmanager
    def connection(self):
        if self.kind == 'mysql':
            conn = self._mysql()
        else:
            conn = sqlite3.connect(self.config['SQLITE_PATH'], timeout=10)
            conn.row_factory = sqlite3.Row
            conn.execute('PRAGMA foreign_keys = ON')
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def execute(self, conn, sql, params=(), fetch=False):
        cursor = conn.cursor(dictionary=True) if self.kind == 'mysql' else conn.cursor()
        try:
            cursor.execute(sql.replace('?', '%s') if self.kind == 'mysql' else sql, params)
            return [dict(r) for r in cursor.fetchall()] if fetch else cursor.lastrowid
        finally:
            cursor.close()

    def initialize(self):
        path = ROOT / 'database' / ('schema.sql' if self.kind == 'mysql' else 'sqlite_schema.sql')
        script = '\n'.join(line for line in path.read_text().splitlines() if not line.strip().startswith('--'))
        with self.connection() as conn:
            for statement in script.split(';'):
                if statement.strip():
                    self.execute(conn, statement)
            for crop in CROPS:
                found = self.execute(conn, 'SELECT id FROM crops WHERE id=?', (crop['id'],), True)
                values = (crop['name'], crop['family'], json.dumps(crop['seasons']),
                          crop['water'], crop['drought'], 'Illustrative synthetic demo profile')
                if not found:
                    self.execute(conn, 'INSERT INTO crops (name,family,seasons,water_requirement,drought_suitability,data_source,id) VALUES (?,?,?,?,?,?,?)', (*values, crop['id']))

    def healthy(self):
        try:
            with self.connection() as conn:
                self.execute(conn, 'SELECT 1', fetch=True)
            return True
        except (sqlite3.Error, mysql.connector.Error):
            return False

    def user(self, anonymous_key):
        with self.connection() as conn:
            rows = self.execute(conn, 'SELECT id FROM users WHERE anonymous_key=?', (anonymous_key,), True)
            if rows:
                return rows[0]['id']
            # Ignore only a duplicate key caused by concurrent first requests.
            prefix = 'INSERT IGNORE' if self.kind == 'mysql' else 'INSERT OR IGNORE'
            self.execute(conn, prefix + ' INTO users (anonymous_key) VALUES (?)', (anonymous_key,))
            return self.execute(conn, 'SELECT id FROM users WHERE anonymous_key=?', (anonymous_key,), True)[0]['id']

    def save_recommendation(self, user_id, profile, results, version):
        with self.connection() as conn:
            farm = self.execute(conn, 'INSERT INTO farm_profiles (user_id,district,season,farm_size,irrigation,previous_crop) VALUES (?,?,?,?,?,?)',
                                (user_id, *(profile[k] for k in ['district', 'season', 'farm_size', 'irrigation', 'previous_crop'])))
            self.execute(conn, 'INSERT INTO soil_data (farm_id,nitrogen,phosphorus,potassium,ph,soil_moisture) VALUES (?,?,?,?,?,?)',
                         (farm, *(profile[k] for k in ['nitrogen', 'phosphorus', 'potassium', 'ph', 'soil_moisture'])))
            self.execute(conn, 'INSERT INTO weather_data (farm_id,temperature,rainfall,humidity,scenario) VALUES (?,?,?,?,?)',
                         (farm, *(profile[k] for k in ['temperature', 'rainfall', 'humidity', 'scenario'])))
            return self.execute(conn, 'INSERT INTO recommendations (user_id,farm_id,inputs_json,results_json,model_version) VALUES (?,?,?,?,?)',
                                (user_id, farm, json.dumps(profile), json.dumps(results), version))

    def history(self, user_id):
        with self.connection() as conn:
            rows = self.execute(conn, 'SELECT id,inputs_json,results_json,created_at FROM recommendations WHERE user_id=? ORDER BY id DESC LIMIT 10', (user_id,), True)
        return [dict(id=r['id'], inputs=json.loads(r['inputs_json']),
                     results=json.loads(r['results_json']), created_at=str(r['created_at'])) for r in rows]

    def farmer_profile(self, user_id):
        with self.connection() as conn:
            rows = self.execute(conn, 'SELECT profile_json,updated_at FROM farmer_profiles WHERE user_id=?',
                                (user_id,), True)
        if not rows:
            return None
        return {'profile': json.loads(rows[0]['profile_json']), 'updated_at': str(rows[0]['updated_at'])}

    def save_farmer_profile(self, user_id, profile):
        encoded = json.dumps(profile, ensure_ascii=False)
        with self.connection() as conn:
            rows = self.execute(conn, 'SELECT user_id FROM farmer_profiles WHERE user_id=?', (user_id,), True)
            if rows:
                self.execute(conn, 'UPDATE farmer_profiles SET profile_json=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?',
                             (encoded, user_id))
            else:
                self.execute(conn, 'INSERT INTO farmer_profiles (user_id,profile_json) VALUES (?,?)',
                             (user_id, encoded))

    def interactions(self):
        with self.connection() as conn:
            return self.execute(conn, 'SELECT user_id,crop_id,action FROM farmer_crop_interactions ORDER BY id', fetch=True)

    def save_interaction(self, user_id, recommendation_id, crop_id, action):
        with self.connection() as conn:
            rows = self.execute(conn, 'SELECT results_json FROM recommendations WHERE id=? AND user_id=?', (recommendation_id, user_id), True)
            if not rows or crop_id not in [c['crop_id'] for c in json.loads(rows[0]['results_json'])]:
                raise ValueError('Choose a crop from one of your own saved recommendations.')
            rows = self.execute(conn, 'SELECT id FROM farmer_crop_interactions WHERE user_id=? AND recommendation_id=? AND crop_id=?', (user_id, recommendation_id, crop_id), True)
            if rows:
                self.execute(conn, 'UPDATE farmer_crop_interactions SET action=?,created_at=CURRENT_TIMESTAMP WHERE id=?', (action, rows[0]['id']))
            else:
                self.execute(conn, 'INSERT INTO farmer_crop_interactions (user_id,recommendation_id,crop_id,action) VALUES (?,?,?,?)', (user_id, recommendation_id, crop_id, action))

    def admin_records(self):
        """Read existing local records for the opt-in, loopback-only admin viewer."""
        with self.connection() as conn:
            users = self.execute(conn,
                'SELECT u.id,u.created_at,p.profile_json,p.updated_at FROM users u '
                'LEFT JOIN farmer_profiles p ON p.user_id=u.id ORDER BY u.id DESC', fetch=True)
            recommendations = self.execute(conn,
                'SELECT r.id,r.user_id,r.farm_id,r.inputs_json,r.results_json,r.model_version,r.created_at,'
                'f.district,f.season,f.farm_size,f.irrigation,f.previous_crop '
                'FROM recommendations r LEFT JOIN farm_profiles f ON f.id=r.farm_id '
                'ORDER BY r.id DESC', fetch=True)
            interactions = self.execute(conn,
                'SELECT recommendation_id,crop_id,action,created_at FROM farmer_crop_interactions '
                'ORDER BY id DESC', fetch=True)
        feedback = {}
        for row in interactions:
            feedback.setdefault(row['recommendation_id'], []).append({
                'crop_id': row['crop_id'], 'action': row['action'], 'created_at': str(row['created_at'])})
        by_user = {}
        for row in recommendations:
            rid = row['id']
            record = {'id': rid, 'farm_id': row['farm_id'], 'district': row['district'],
                      'season': row['season'], 'farm_size': row['farm_size'],
                      'irrigation': row['irrigation'], 'previous_crop': row['previous_crop'],
                      'inputs': json.loads(row['inputs_json']), 'results': json.loads(row['results_json']),
                      'model_version': row['model_version'], 'created_at': str(row['created_at']),
                      'feedback': feedback.get(rid, [])}
            by_user.setdefault(row['user_id'], []).append(record)
        result = []
        for row in users:
            result.append({'user_id': row['id'], 'created_at': str(row['created_at']),
                           'profile': json.loads(row['profile_json']) if row['profile_json'] else None,
                           'profile_updated_at': str(row['updated_at']) if row['updated_at'] else None,
                           'recommendations': by_user.get(row['id'], [])})
        return result
