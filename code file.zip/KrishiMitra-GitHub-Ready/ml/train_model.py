"""Run from project root: python -m ml.train_model."""
import hashlib
import json
from pathlib import Path

import joblib
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline

from ml.generate_data import generate
from ml.preprocess import FEATURES, TARGET, preprocessor
from ml.evaluate_model import evaluate

ROOT = Path(__file__).resolve().parents[1]


def train():
    data_dir, model_dir = ROOT / 'ml/data', ROOT / 'ml/models'
    data_dir.mkdir(parents=True, exist_ok=True)
    model_dir.mkdir(parents=True, exist_ok=True)
    train_data = generate(rows=4800, seed=42)
    test_data = generate(rows=1200, seed=91042)
    train_data.to_csv(data_dir / 'synthetic_demo.csv', index=False)
    test_data.to_csv(data_dir / 'holdout.csv', index=False)
    pipeline = Pipeline([
        ('preprocess', preprocessor()),
        ('forest', RandomForestClassifier(n_estimators=300, max_depth=None,
                                         min_samples_leaf=1, max_features=1.0,
                                         random_state=42, n_jobs=2)),
    ])
    pipeline.fit(train_data[FEATURES], train_data[TARGET])
    fingerprint_hash = hashlib.sha256()
    fingerprint_hash.update((data_dir / 'synthetic_demo.csv').read_bytes())
    fingerprint_hash.update((data_dir / 'holdout.csv').read_bytes())
    fingerprint = fingerprint_hash.hexdigest()
    bundle = dict(pipeline=pipeline, features=FEATURES, data_source='SYNTHETIC_DEMO',
                  version='synthetic-rule-v2-' + fingerprint[:10], sklearn_version=sklearn.__version__,
                  training_rows=len(train_data), test_rows=len(test_data), dataset_sha256=fingerprint,
                  majority_class=str(train_data[TARGET].mode()[0]),
                  label_method='deterministic_argmax_of_synthetic_crop_profile_score',
                  holdout_seed=91042)
    metrics = evaluate(bundle, test_data)
    metrics['training_rows'] = len(train_data)
    metrics['majority_class_baseline_accuracy'] = float((test_data[TARGET] == train_data[TARGET].mode()[0]).mean())
    metrics['label_method'] = bundle['label_method']
    metrics['holdout_seed'] = bundle['holdout_seed']
    metrics['interpretation'] = 'Agreement with deterministic synthetic crop-profile scoring rules; not real-world agricultural accuracy.'
    temporary = model_dir / 'random_forest.tmp'
    joblib.dump(bundle, temporary)
    temporary.replace(model_dir / 'random_forest.joblib')
    (model_dir / 'metrics.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')
    print('Trained RandomForestClassifier on SYNTHETIC RULE demonstration data.')
    print(f'Train: {len(train_data)}; independently generated holdout: {len(test_data)}')
    print(f"Synthetic rule-match accuracy: {metrics['accuracy']:.3f}; macro F1: {metrics['f1_macro']:.3f}")
    print('These results measure rule reproduction only, not real-world crop suitability.')
    return bundle


if __name__ == '__main__':
    train()
