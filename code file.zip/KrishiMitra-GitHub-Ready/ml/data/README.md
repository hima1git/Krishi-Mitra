# Synthetic rule-match dataset

`python -m ml.train_model` creates 4,800 synthetic training rows and a separate
1,200-row synthetic holdout. The holdout is generated from a different fixed
seed (91042), rather than being a random split from the training rows.

No row is measured farm, soil, weather, crop-yield, or farmer-outcome data.
Numeric and categorical inputs are sampled for an educational demonstration.
The target label is the crop with the highest score under the illustrative
crop-profile formula in `ml/generate_data.py`. Training accuracy therefore
measures how well the Random Forest reproduces those programmed rules on a
separate synthetic sample. It is not real-world crop-suitability accuracy, a
probability of success, or validation of agricultural advice.

The fixed training and holdout seeds make the benchmark reproducible. The
preprocessor is fit only on the training partition. District, farm size, and
previous crop are independently sampled contextual variables; the generator
does not encode district-specific yield effects. Previous crop is used by the
recommendation engine's diversification filter.

`rainfall` is an assumed seasonal total in millimeters, not current daily
rainfall. `scenario` is a user-selected simulation and is not inferred from
rainfall or an ENSO forecast. Soil nutrients use illustrative kg/ha values;
no soil-test method calibration is provided.

When reloading CSVs, use `keep_default_na=False` because the category `None`
means no previous crop, not a missing value. Use `float_precision='round_trip'`
to preserve serialized numeric values.
