"""Shared training/inference features: identical names and transformations."""
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from backend.utils.validation import NUMERIC_BOUNDS, CATEGORIES

NUMERIC_FEATURES = list(NUMERIC_BOUNDS)
CATEGORICAL_FEATURES = list(CATEGORIES)
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES
TARGET = 'recommended_crop'


def preprocessor():
    numeric = Pipeline([('impute', SimpleImputer(strategy='median'))])
    categorical = Pipeline([
        ('impute', SimpleImputer(strategy='most_frequent')),
        ('encode', OneHotEncoder(handle_unknown='ignore')),
    ])
    return ColumnTransformer([('numeric', numeric, NUMERIC_FEATURES),
                              ('categorical', categorical, CATEGORICAL_FEATURES)])
