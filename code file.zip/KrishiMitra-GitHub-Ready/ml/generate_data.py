"""Synthetic rule-match examples. No observed farmer or crop-yield data."""
import numpy as np
import pandas as pd

from backend.catalog import CROPS, DISTRICTS, SEASONS, SCENARIOS, PREVIOUS_CROPS


def generate(rows=4800, seed=42):
    rng = np.random.default_rng(seed)
    records = []
    scales = np.array([65, 45, 65, 1.2, 8, 450, 25, 30])
    for _ in range(rows):
        season = str(rng.choice(SEASONS))
        scenario = str(rng.choice(SCENARIOS))
        irrigation = str(rng.choice(['yes', 'no']))
        values = np.array([rng.uniform(5, 140), rng.uniform(5, 100), rng.uniform(5, 160),
                           rng.uniform(5, 8.5), rng.uniform(17, 38), rng.uniform(100, 1600),
                           rng.uniform(30, 95), rng.uniform(10, 90)])
        candidates = [c for c in CROPS if season in c['seasons']]
        scores = []
        for crop in candidates:
            score = -np.mean(((values - np.array(crop['center'])) / scales) ** 2)
            if scenario != 'normal':
                score += {'High': .7, 'Moderate': .1, 'Low': -.8}[crop['drought']]
            if scenario == 'severe_stress' and irrigation == 'no' and crop['water'] == 'High':
                score -= 4
            if irrigation == 'yes' and crop['water'] == 'High':
                score += .4
            scores.append(score)
        # The target is the top crop under the same illustrative profile score.
        # Evaluation measures rule reproduction, never real-world crop suitability.
        target = candidates[int(np.argmax(scores))]['name']
        records.append(dict(zip(['nitrogen', 'phosphorus', 'potassium', 'ph', 'temperature',
                                 'rainfall', 'humidity', 'soil_moisture'], values)) |
                       dict(district=str(rng.choice(DISTRICTS)), season=season,
                            scenario=scenario, irrigation=irrigation,
                            previous_crop=str(rng.choice(PREVIOUS_CROPS)),
                            farm_size=round(float(rng.uniform(.2, 15)), 2),
                            recommended_crop=target, data_source='SYNTHETIC_DEMO'))
    return pd.DataFrame(records)
