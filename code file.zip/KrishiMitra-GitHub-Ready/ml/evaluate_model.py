"""Evaluate the serialized model on an independently generated synthetic holdout."""
import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix, classification_report

from ml.preprocess import FEATURES, TARGET

ROOT = Path(__file__).resolve().parents[1]


def evaluate(bundle, test):
    pipeline = bundle['pipeline']
    predicted = pipeline.predict(test[FEATURES])
    labels = list(pipeline.named_steps['forest'].classes_)
    precision, recall, f1, _ = precision_recall_fscore_support(test[TARGET], predicted, average='macro', zero_division=0)
    importance = pipeline.named_steps['forest'].feature_importances_
    names = pipeline.named_steps['preprocess'].get_feature_names_out()
    return {
        'data_source': bundle['data_source'], 'model_version': bundle['version'],
        'notice': 'Synthetic holdout metrics measure reproduction of deterministic crop-profile rules, not agricultural validity.',
        'interpretation': bundle.get('interpretation', 'Synthetic rule-match evaluation; not real-world agricultural accuracy.'),
        'training_rows': bundle['training_rows'],
        'majority_class_baseline_accuracy': float((test[TARGET] == bundle['majority_class']).mean()),
        'test_rows': len(test), 'accuracy': accuracy_score(test[TARGET], predicted),
        'precision_macro': precision, 'recall_macro': recall, 'f1_macro': f1,
        'confusion_matrix': confusion_matrix(test[TARGET], predicted, labels=labels).tolist(),
        'class_order': labels,
        'classification_report': classification_report(test[TARGET], predicted, zero_division=0, output_dict=True),
        'feature_importance': sorted([{'feature': str(name), 'importance': float(value)}
                                      for name, value in zip(names, importance)],
                                     key=lambda r: r['importance'], reverse=True),
    }


def main():
    bundle = joblib.load(ROOT / 'ml/models/random_forest.joblib')
    # "None" is an actual previous-crop category, not a missing CSV value.
    test = pd.read_csv(ROOT / 'ml/data/holdout.csv', keep_default_na=False, float_precision='round_trip')
    report = evaluate(bundle, test)
    (ROOT / 'ml/models/metrics.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({k: report[k] for k in ['data_source', 'test_rows', 'accuracy', 'precision_macro', 'recall_macro', 'f1_macro']}, indent=2))


if __name__ == '__main__':
    main()
