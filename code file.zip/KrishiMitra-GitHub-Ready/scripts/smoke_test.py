"""Exercise the actual Windows launcher and live HTTP APIs in an isolated DB."""
import http.cookiejar
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parents[1]


def main():
    if os.name != 'nt':
        raise RuntimeError('This smoke test specifically verifies the Windows launcher.')
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    directory = ROOT / 'instance' / ('smoke-' + uuid.uuid4().hex[:8])
    directory.mkdir(parents=True)
    environment = dict(os.environ, PORT=str(port), DB_MODE='sqlite', SQLITE_PATH=str(directory / 'smoke.db'))
    base = f'http://127.0.0.1:{port}'
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    with (directory / 'startup.log').open('w', encoding='utf-8') as log:
        process = subprocess.Popen(['cmd.exe', '/d', '/c', 'run.bat'], cwd=ROOT,
                                   env=environment, stdout=log, stderr=log,
                                   creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
        (directory / 'launcher.pid').write_text(str(process.pid), encoding='utf-8')
        try:
            health = None
            for _ in range(60):
                if process.poll() is not None:
                    raise RuntimeError('Launcher exited before becoming ready. Check the smoke startup log.')
                try:
                    health = json.load(opener.open(base + '/api/health', timeout=2))
                    break
                except (OSError, urllib.error.URLError):
                    time.sleep(.5)
            assert health and health['backend_status'] == 'ok', 'Server did not become ready.'
            assert health['database']['type'] == 'sqlite'
            print('PASS: run.bat -> setup -> server -> healthy SQLite/model')
            info = json.load(opener.open(base + '/api/system-info'))
            def post(path, body):
                return opener.open(urllib.request.Request(base + path, data=json.dumps(body).encode(),
                                   headers={'Content-Type': 'application/json', 'X-CSRF-Token': info['csrf_token']}))
            profile = dict(district='Akola', season='Kharif', farm_size=2.5, nitrogen=50,
                           phosphorus=35, potassium=40, ph=6.7, temperature=29,
                           rainfall=650, humidity=65, soil_moisture=40, irrigation='no',
                           previous_crop='Cotton', scenario='below_normal')
            result = json.load(post('/api/recommend', profile))
            assert len(result['recommendations']) == 3
            feedback = dict(recommendation_id=result['recommendation_id'],
                            crop_id=result['recommendations'][0]['crop_id'], action='accepted')
            assert json.load(post('/api/interactions', feedback))['status'] == 'saved'
            assert len(json.load(opener.open(base + '/api/system-info'))['history']) == 1
            print('PASS: recommendation, feedback and saved history over HTTP')
            try:
                post('/api/recommend', dict(profile, ph=20))
            except urllib.error.HTTPError as error:
                assert error.code == 400
            else:
                raise AssertionError('Invalid pH was accepted')
            for path in ['/', '/static/css/style.css', '/static/js/app.js', '/api/crops']:
                assert opener.open(base + path).status == 200
            print('PASS: invalid-input handling and frontend asset delivery')
        finally:
            # Terminate only the exact process tree created by this test.
            stopped = subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True, text=True)
            if stopped.returncode and process.poll() is None:
                raise RuntimeError(f'Test-process cleanup was denied for PID {process.pid}. Run the smoke test outside the restricted sandbox.')
            process.wait(timeout=15)
    print(f'Launcher smoke test passed. Logs: {directory.relative_to(ROOT)}')


if __name__ == '__main__':
    main()
