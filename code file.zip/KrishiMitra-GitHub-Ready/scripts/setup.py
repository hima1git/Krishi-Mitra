"""Bootstrap in an isolated venv using only the standard library first."""
import argparse
import importlib.metadata
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
VENV = ROOT / 'venv'
PYTHON = VENV / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def run(arguments):
    subprocess.run([str(arg) for arg in arguments], cwd=ROOT, check=True)


def main():
    parser = argparse.ArgumentParser(description='Prepare Krishi Mitra and optionally start it.')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    os.chdir(ROOT)
    if not PYTHON.exists():
        print('Creating project-specific virtual environment...', flush=True)
        run([sys.executable, '-m', 'venv', VENV])
    if Path(sys.prefix).resolve() != VENV.resolve():
        run([PYTHON, __file__, *sys.argv[1:]])
        return
    if subprocess.run([str(PYTHON), '-m', 'pip', '--version'], capture_output=True).returncode:
        run([PYTHON, '-m', 'ensurepip', '--upgrade'])
    # Pin transitive packages on this supported Windows/Python runtime too.
    requirements = ROOT / 'requirements-lock.txt'
    if not requirements.exists():
        requirements = ROOT / 'requirements.txt'
    missing = []
    for line in requirements.read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        name, version = line.split('==')
        try:
            if importlib.metadata.version(name) != version:
                missing.append(name)
        except importlib.metadata.PackageNotFoundError:
            missing.append(name)
    if missing:
        print('Installing required packages in venv: ' + ', '.join(missing), flush=True)
        run([PYTHON, '-m', 'pip', 'install', '-r', requirements])
    else:
        print('Dependencies already match; no downloads needed.', flush=True)
    run([PYTHON, '-m', 'pip', 'check'])
    if not (ROOT / '.env').exists():
        shutil.copyfile(ROOT / '.env.example', ROOT / '.env')
        print('Created .env with no database credentials. SQLite fallback is available.', flush=True)
    sys.path.insert(0, str(ROOT))
    from backend.config import settings
    from backend.services.recommendation import Recommender
    config = settings()
    model = Recommender(config)
    if model.bundle is None:
        print('Model missing or incompatible. Training SYNTHETIC demonstration model...', flush=True)
        run([PYTHON, '-m', 'ml.train_model'])
    from backend.database.store import Store
    store = Store(config)
    print(f'Database: {store.kind.upper()}. {store.message}', flush=True)
    print('Setup complete. Start with run.bat or scripts/run.ps1.', flush=True)
    if args.run:
        run([PYTHON, '-m', 'backend.app'])


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nKrishi Mitra stopped.')
    except subprocess.CalledProcessError as error:
        print(f'Setup/startup command failed (exit {error.returncode}). See the error above and README troubleshooting.', file=sys.stderr)
        sys.exit(error.returncode or 1)
    except Exception as error:
        print(f'Setup could not finish ({type(error).__name__}). Check README troubleshooting and .env locally; credentials are never printed.', file=sys.stderr)
        sys.exit(1)
