param([switch]$Run)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot

function Find-ProjectPython {
    $candidates = @((Join-Path $projectRoot 'venv\Scripts\python.exe'))
    foreach ($commandName in @('python', 'python3')) {
        $command = Get-Command $commandName -ErrorAction SilentlyContinue
        if ($command -and $command.Source -notlike '*WindowsApps*') { $candidates += $command.Source }
    }
    $launcher = Get-Command py -ErrorAction SilentlyContinue
    if ($launcher) {
        $found = & $launcher.Source -3 -c 'import sys; print(sys.executable)' 2>$null
        if ($LASTEXITCODE -eq 0) { $candidates += $found }
    }
    $candidates += @(Get-ChildItem -Path "$env:LOCALAPPDATA\Programs\Python\Python*\python.exe" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
    $candidates += (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe')
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) {
            & $candidate -c 'import sys,venv; assert (3,12) <= sys.version_info[:2] <= (3,13)' 2>$null
            if ($LASTEXITCODE -eq 0) { return $candidate }
        }
    }
    return $null
}

try {
    $pythonExe = Find-ProjectPython
    if (-not $pythonExe) {
        $winget = Get-Command winget -ErrorAction SilentlyContinue
        if ($winget) {
            Write-Host 'Python is missing. Attempting a current-user Python 3.12 installation with Windows Package Manager.'
            & $winget.Source install --id Python.Python.3.12 --exact --scope user --silent --accept-package-agreements --accept-source-agreements
            $pythonExe = Find-ProjectPython
        }
    }
    if (-not $pythonExe) {
        Write-Host 'Install Python 3.12 (64-bit) from https://www.python.org/downloads/windows/.' -ForegroundColor Yellow
        Write-Host 'Choose Install Now for your user and enable Add python.exe to PATH. Then double-click run.bat again.'
        exit 1
    }
    Write-Host "Using Python: $pythonExe"
    if ($Run) { & $pythonExe (Join-Path $PSScriptRoot 'setup.py') --run }
    else { & $pythonExe (Join-Path $PSScriptRoot 'setup.py') }
    exit $LASTEXITCODE
} catch {
    Write-Host 'Setup could not run. Check Python installation and the README troubleshooting section.' -ForegroundColor Red
    Write-Host $_.Exception.GetType().Name
    exit 1
}
