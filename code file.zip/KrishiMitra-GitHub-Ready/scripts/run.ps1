$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'setup.ps1') -Run
exit $LASTEXITCODE
