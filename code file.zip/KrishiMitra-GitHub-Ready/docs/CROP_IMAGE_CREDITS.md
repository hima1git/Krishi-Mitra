# Crop image credits

The five crop photographs below are local thumbnails served from `frontend/images/crops/`; card images do not hotlink external sites. Each source page confirms the listed license. Thumbnail variants were obtained from Wikimedia Commons at 480 px wide and are used as small card photos. No other edits were made.

| Crop | Local file | Image and creator | License | Source |
| --- | --- | --- | --- | --- |
| Sorghum | `sorghum-photo.jpg` | “Sorghum field.jpg” — Tomascastelazo | CC BY-SA 3.0 | [Commons file page](https://commons.wikimedia.org/wiki/File:Sorghum_field.jpg) |
| Pearl millet | `pearl-millet-photo.jpg` | “Pearl millet in summer.jpg” — Herovaclicks | CC BY 4.0 | [Commons file page](https://commons.wikimedia.org/wiki/File:Pearl_millet_in_summer.jpg) |
| Pigeon pea | `pigeon-pea-photo.jpg` | “Pigeon Pea field in Andhra Pradesh (50164).jpg” — PJeganathan | CC BY-SA 3.0 | [Commons file page](https://commons.wikimedia.org/wiki/File:Pigeon_Pea_field_in_Andhra_Pradesh_(50164).jpg) |
| Green gram | `green-gram-photo.jpg` | “Green gram field.jpg” — Jayanitilak | CC BY-SA 4.0 | [Commons file page](https://commons.wikimedia.org/wiki/File:Green_gram_field.jpg) |
| Soybean | `soybean-photo.jpg` | “Soybean Field (9623893574).jpg” — United Soybean Board | CC BY 2.0 | [Commons file page](https://commons.wikimedia.org/wiki/File:Soybean_Field_(9623893574).jpg) |

The app displays creator, license, and source-page links from the centralized crop catalog inside each crop's “Crop Details” disclosure. The sorghum, pearl millet, pigeon pea, green gram and soybean photographs cover the Kharif alternatives returned in the standard example. Remaining target crops retain the existing local illustration placeholder; those files are not presented as photographs.

CC BY-SA assets remain subject to the same or compatible share-alike license when redistributed. Preserve this attribution file when distributing the project or any of these image assets.
