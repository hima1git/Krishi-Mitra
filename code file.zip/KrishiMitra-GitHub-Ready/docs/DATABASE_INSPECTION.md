# Local database and stored usage data

## Current database

The application uses the existing SQLite database at `instance/krishimitra.db` by default. `backend/config.py` sets the path through `SQLITE_PATH`. `backend/database/store.py` initializes it from `database/sqlite_schema.sql` without replacing existing rows. The project also contains `database/schema.sql` and optional MySQL configuration (`DB_MODE`, `MYSQL_HOST`, `MYSQL_PORT`, `MYSQL_DATABASE`, `MYSQL_USER`, `MYSQL_PASSWORD`). No MySQL server is required when the app reports SQLite as its active database.

## Important tables

| Table | Contents |
| --- | --- |
| `users` | Anonymous browser profile ID, random browser key, first-seen time. The admin viewer intentionally omits the key. |
| `farmer_profiles` | One JSON profile per user plus last update time. Includes only existing profile fields and optional farmer-entered weather values. |
| `farm_profiles` | A row for each recommendation run: user, district, season, area, irrigation, previous crop, and time. |
| `soil_data` | N/P/K, pH, and soil moisture for a recommendation run. Assumed model values are preserved in the recommendation JSON with provenance. |
| `weather_data` | The submitted temperature, rainfall, humidity, and rainfall scenario for a recommendation run. |
| `recommendations` | Run ID, user/farm IDs, model version, full input/provenance JSON, ranked crop results JSON, and time. |
| `farmer_crop_interactions` | Existing selected/accepted/rejected feedback linked to a user, recommendation, and crop. |
| `crops` | Seeded crop catalog. |

Farmer profile fields are stored in `farmer_profiles.profile_json`. Recommendation inputs and results are in `recommendations.inputs_json` and `recommendations.results_json`; associated farm and soil/weather rows are in `farm_profiles`, `soil_data`, and `weather_data`. Feedback is in `farmer_crop_interactions`. No phone or email fields are collected.

## Local inspection

From the project root, with the project virtual environment active, run:

```powershell
python -c "import sqlite3; c=sqlite3.connect('instance/krishimitra.db'); print('\n'.join(r[0] for r in c.execute(\"select name from sqlite_master where type='table' order by name\"))); c.close()"
```

For individual profile/history values, SQLite Browser or the local viewer is more convenient. Treat exported records as private farm data.

## Local developer viewer

The existing database is viewed at `http://127.0.0.1:5000/admin/farmers` after explicitly enabling `LOCAL_ADMIN_VIEW=true` in the local process environment and restarting the server. The app also rejects requests whose direct client IP is not loopback. The viewer is read-only and absent from farmer-facing navigation/API responses. It has no login system; keep the server bound to localhost, do not expose it through a public reverse proxy, and keep `LOCAL_ADMIN_VIEW` unset/false for any public deployment. Add real authentication and authorization before making any admin data viewer public.

The viewer reads the existing profile, recommendation, and feedback tables. It does not create another database or collect additional personal information. Anonymous browser identity is cookie-based; clearing cookies creates a different anonymous user record.
