# Official ENSO status and decision-support scenarios

The existing Random Forest and rainfall-scenario feature are unchanged. The separate `climate_scenario` field defaults to `normal`, is removed before model validation, and is saved in the existing recommendation JSON snapshot. It does not change model features, scores, ranking, or database schema.

## Current official global ENSO status

`GET /api/enso` fetches the current NOAA CPC ENSO Diagnostic Discussion and the NOAA CPC historical RONI table. The diagnostic page supplies its published issue date, ENSO Alert System status, state, trend wording, and any forecast strength/probability statement. The RONI table supplies the latest completed overlapping-season index and a displayed strength band; episode classification requires five consecutive published seasons past NOAA's threshold. Observation, discussion issue date, app retrieval time, and forecast statement are kept distinct. The service caches for one hour, then fetches again; on a retrieval or parsing failure the official status is `unavailable`, with no stale value passed off as current.

NOAA CPC sources: [ENSO Diagnostic Discussion](https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso_advisory/ensodisc.html), [RONI history](https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso/roni/), [RONI outlook](https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso/roni/outlook/). ENSO describes global Pacific conditions; it does not determine rainfall for a particular Vidarbha district.

## Hypothetical stress scenarios

The existing definitions remain in `backend/data/climate_scenarios.json`: Normal / Current Conditions, Moderate El Niño, Strong El Niño, and Extreme El Niño stress scenario. “Extreme” is a hypothetical decision-support scenario, not an official NOAA category. These options are simulations, not forecasts. They are separate from the official meter and do not alter the Random Forest scores or inputs.

Crop-level scenario messages retain `suitability_change: not_assessed`. Catalog water and drought descriptors are illustrative, and the project has no verified district crop-response calibration to support crop-specific ENSO score adjustments.
