# Validation report — 26 September 2026

## Automated checks

- `python -m pip check`: no broken requirements.
- Imports: Flask, pandas, NumPy, scikit-learn, joblib, python-dotenv, mysql.connector, Waitress all imported from the venv.
- `python -m compileall -q backend ml`: passed.
- `node --check frontend/js/app.js`: passed; Node is not needed to run the app.
- `python -m pytest -q`: **61 passed** after the synthetic rule-match model update.

Coverage includes actual RandomForestClassifier probability inference, input bounds/categories, NaN/infinity/boolean rejection, CSRF, malformed JSON, content types, persisted linked database rows, idempotent seed initialization, foreign keys, feedback updates, session ownership, severe-water filtering, fewer-than-three results, collaborative neighbors and cold start, simulated MySQL connection failure, missing-model health, served assets, and CSV/model evaluation reproducibility.

## Startup and HTTP smoke test

`python scripts/smoke_test.py` launched the actual `run.bat` chain using a separate SQLite database and ephemeral port. Passed:

- Existing dependency detection (no unnecessary downloads).
- Flask/Waitress startup, health response, active SQLite status, ready model.
- Real HTTP recommendation, feedback, and saved-history calls with cookies and CSRF.
- Invalid pH rejected with HTTP 400.
- Home page, CSS, JavaScript, and crop endpoint served successfully.
- Test process tree terminated after verification.

The first sandboxed test passed functional checks but Windows denied its process cleanup. The exact test process tree was stopped with approved escalation. A rerun outside the sandbox passed completely, including cleanup. Final log: `instance/smoke-5ff73f8d/startup.log`.

## Automatic missing-model recovery

The existing generated artifact was moved to `instance/model-before-bootstrap.joblib`, then `scripts/setup.py` was run. It detected the missing model, trained and serialized the synthetic model, initialized the database, and completed. The test suite passed afterward. The original generated artifact remains as a local ignored backup.

## Model evaluation

Training: 4,800 generated synthetic rows (seed 42). Independent holdout: 1,200 separately generated rows (seed 91042). The target is the highest scoring crop under the project's illustrative synthetic crop-profile formula.

| Metric | Value |
|---|---:|
| Synthetic rule-match accuracy | 0.888333 |
| Macro precision | 0.738978 |
| Macro recall | 0.686728 |
| Macro F1 | 0.692403 |
| Majority-class accuracy baseline | 0.635000 |

This updated score measures reproduction of deterministic synthetic crop-profile rules on a separately generated holdout. It does not measure real-world crop suitability, yield, or farmer outcomes. The earlier stochastic-label experiment scored 0.442500 and is superseded by the current model and metrics artifact.

Full confusion matrix, per-class report, and feature importances are in `ml/models/metrics.json`. No real-field or crop-outcome accuracy is asserted.

A small training/reload evaluation discrepancy was traced to pandas interpreting the previous-crop string `None` as a missing CSV value. The loader now preserves that category and float precision. The regression test compares the saved accuracy and complete confusion matrix with independent re-evaluation.

## Browser verification

Used the in-app Browser against the actual local server:

- Home navigation and all 15 form inputs rendered.
- Submitted the demo inputs; three ranked crop cards showed distinct RF, CF, and final scores.
- Accepted one crop; the UI confirmed saved feedback.
- Dashboard displayed the saved run and crop list.
- System status displayed SQLite fallback, ready model, Python version, and measured metrics.
- Entered pH 20; native form validation rejected it. Load demo inputs restored pH 6.7.
- Inspected the form at a 390 × 844 viewport; no page-wide horizontal overflow. Navigation scrolls horizontally on narrow screens.
- No captured browser console warnings or errors during the tested flow.

Screenshots are in `docs/screenshots/`. Browser-test feedback is local demonstration activity, not real farmer behavior. Automated tests use separate temporary databases.

## Remaining limitations

- MySQL is installed and running, but credentials were not supplied. No credentialed MySQL success-path test was performed; MySQL connector support/schema and simulated connection-failure fallback are implemented.
- Python-absent installation via winget is implemented but was not executed because usable Python already existed. UAC or organization policies may require user action on another computer.
- Verified runtime: Windows with Python 3.12.14. Other supported Python versions are not claimed as tested.
- Synthetic classification and preference feedback do not establish agronomic validity.
