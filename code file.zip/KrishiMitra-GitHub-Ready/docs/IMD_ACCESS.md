# IMD weather access and district provenance

The adapter uses endpoints documented in the official [IMD API reference](https://api.imd.gov.in/public/api_reference.html): district rainfall, 5-day district rainfall forecast, district warnings, and AWS/ARG observations for Maharashtra (state id 21). The APIs can return lists; the adapter matches the returned `District` field to the currently requested Vidarbha district before exposing any record. Values are never shared across districts. Unmatched or malformed records are withheld.

Unauthenticated requests to the official API returned HTTP 401. Register through the [IMD API Management Portal](https://api.imd.gov.in/public/index.php) and follow IMD's authorized credentials and terms. The app does not bypass authentication or access restrictions. Configure `IMD_API_AUTH_HEADER` and `IMD_API_AUTH_VALUE` only with the authorized values. When either is absent or retrieval fails, live weather is reported as unavailable. API values are kept out of logs.

The response carries source URLs, requested district, data type, retrieval time, observation/issue date, and an explicit `model_input: false`. Successful responses are cached per district for `IMD_CACHE_SECONDS` (default 900); the timeout is `IMD_API_TIMEOUT` (default 5 seconds).

## Available fallback

The existing ICAR-CRIDA district contingency-plan table contains annual and southwest-monsoon rainfall normals for each supported district, but its averaging period is not stated. Those values appear only as `HISTORICAL` regional context with the source link and are not called current/live, not used as seasonal model inputs, and not presented as farm measurements. There is no equivalent verified district default for current temperature, humidity, wind, or weather condition. Farmer-entered local readings are labeled `FARMER PROVIDED` and remain separate from IMD values.
