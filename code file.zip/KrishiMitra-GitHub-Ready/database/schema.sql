-- Run against an existing MySQL database selected by the administrator.
-- No passwords or server-wide changes are made by this script.
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    anonymous_key VARCHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS farmer_profiles (
    user_id INT PRIMARY KEY,
    profile_json LONGTEXT NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS farm_profiles (
    id INT PRIMARY KEY AUTO_INCREMENT, user_id INT NOT NULL,
    district VARCHAR(64) NOT NULL, season VARCHAR(16) NOT NULL,
    farm_size DOUBLE NOT NULL, irrigation VARCHAR(8) NOT NULL,
    previous_crop VARCHAR(64) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS soil_data (
    id INT PRIMARY KEY AUTO_INCREMENT, farm_id INT NOT NULL,
    nitrogen DOUBLE NOT NULL, phosphorus DOUBLE NOT NULL, potassium DOUBLE NOT NULL,
    ph DOUBLE NOT NULL, soil_moisture DOUBLE NOT NULL,
    FOREIGN KEY(farm_id) REFERENCES farm_profiles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS weather_data (
    id INT PRIMARY KEY AUTO_INCREMENT, farm_id INT NOT NULL,
    temperature DOUBLE NOT NULL, rainfall DOUBLE NOT NULL,
    humidity DOUBLE NOT NULL, scenario VARCHAR(32) NOT NULL,
    FOREIGN KEY(farm_id) REFERENCES farm_profiles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS crops (
    id INT PRIMARY KEY, name VARCHAR(64) NOT NULL UNIQUE, family VARCHAR(32) NOT NULL,
    seasons TEXT NOT NULL, water_requirement VARCHAR(16) NOT NULL,
    drought_suitability VARCHAR(16) NOT NULL, data_source VARCHAR(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS recommendations (
    id INT PRIMARY KEY AUTO_INCREMENT, user_id INT NOT NULL, farm_id INT NOT NULL,
    inputs_json LONGTEXT NOT NULL, results_json LONGTEXT NOT NULL,
    model_version VARCHAR(64) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(farm_id) REFERENCES farm_profiles(id),
    INDEX idx_recommendations_user(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS farmer_crop_interactions (
    id INT PRIMARY KEY AUTO_INCREMENT, user_id INT NOT NULL,
    crop_id INT NOT NULL, recommendation_id INT NOT NULL,
    action ENUM('selected','accepted','rejected') NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(crop_id) REFERENCES crops(id),
    FOREIGN KEY(recommendation_id) REFERENCES recommendations(id),
    UNIQUE KEY uq_interaction(user_id,crop_id,recommendation_id),
    INDEX idx_interactions_user_crop(user_id,crop_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
