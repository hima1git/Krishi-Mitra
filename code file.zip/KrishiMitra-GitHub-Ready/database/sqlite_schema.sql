PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    anonymous_key TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS farmer_profiles (
    user_id INTEGER PRIMARY KEY REFERENCES users(id),
    profile_json TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS farm_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    district TEXT NOT NULL, season TEXT NOT NULL,
    farm_size REAL NOT NULL, irrigation TEXT NOT NULL, previous_crop TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS soil_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL REFERENCES farm_profiles(id),
    nitrogen REAL NOT NULL, phosphorus REAL NOT NULL, potassium REAL NOT NULL,
    ph REAL NOT NULL, soil_moisture REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS weather_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farm_id INTEGER NOT NULL REFERENCES farm_profiles(id),
    temperature REAL NOT NULL, rainfall REAL NOT NULL,
    humidity REAL NOT NULL, scenario TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS crops (
    id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, family TEXT NOT NULL,
    seasons TEXT NOT NULL, water_requirement TEXT NOT NULL,
    drought_suitability TEXT NOT NULL, data_source TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS recommendations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    farm_id INTEGER NOT NULL REFERENCES farm_profiles(id),
    inputs_json TEXT NOT NULL, results_json TEXT NOT NULL,
    model_version TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS farmer_crop_interactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    crop_id INTEGER NOT NULL REFERENCES crops(id),
    recommendation_id INTEGER NOT NULL REFERENCES recommendations(id),
    action TEXT NOT NULL CHECK(action IN ('selected','accepted','rejected')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, crop_id, recommendation_id)
);
CREATE INDEX IF NOT EXISTS idx_recommendations_user ON recommendations(user_id);
CREATE INDEX IF NOT EXISTS idx_interactions_user_crop ON farmer_crop_interactions(user_id, crop_id);
